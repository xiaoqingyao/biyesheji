# LicensePlateRecognition
License plate recognition

![](/images/1.jpg)
