I=imread('10.jpg');
figure
imshow(I);
%I=imread('r1.bmp');
%imshow(I);
%J=imnoise(I,'salt&pepper',0.02);
J=imnoise(I,'salt & pepper',0.02);
figure
imshow(J);
%imwrite(J,'r11.bmp','bmp');