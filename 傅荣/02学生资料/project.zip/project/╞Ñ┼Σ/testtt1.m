for i=1:3
if(flag(i)==1)
if(i==1)
im1=imread('result_1.bmp');
end
if(i==2)
    im1=imread('result_2.bmp');
end
if(i==3)
    im1=imread('result_3.bmp');
end
figure,imshow(im1);