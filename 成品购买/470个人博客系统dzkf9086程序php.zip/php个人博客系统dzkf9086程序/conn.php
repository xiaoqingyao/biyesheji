<?php
//���ݿ������ļ�
error_reporting(0); 
$host='127.0.0.1';//���ݿ������
$user='root';//���ݿ��û���
$password='';//���ݿ�����
$database='phpgrbkxt9086';//���ݿ���
$conn=@mysql_connect($host,$user,$password) or die('���ݿ�����ʧ�ܣ�');
@mysql_select_db($database) or die('û���ҵ����ݿ⣡');
mysql_query("set names 'gb2312'");
function getoption($ntable,$nzd)
{
		$sql="select ".$nzd." from ".$ntable." order by id desc";
		$query=mysql_query($sql);
		$rowscount=mysql_num_rows($query);
		if($rowscount>0)
		{
			for ($fi=0;$fi<$rowscount;$fi++)
			{
				?>
				<option value="<?php echo mysql_result($query,$fi,0);?>"><?php echo mysql_result($query,$fi,0);?></option>
				<?php
			}
		}
}
function getoption2($ntable,$nzd)
{
	?>
	<option value="">��ѡ��</option>
	<?php
		$sql="select ".$nzd." from ".$ntable." order by id desc";
		$query=mysql_query($sql);
		$rowscount=mysql_num_rows($query);
		if($rowscount>0)
		{
			for ($fi=0;$fi<$rowscount;$fi++)
			{
				?>
				<option value="<?php echo mysql_result($query,$fi,0);?>" <?php 
				
				if($_GET[$nzd]==mysql_result($query,$fi,0))
				{
					echo "selected";
				}
				?>><?php echo mysql_result($query,$fi,0);?></option>
				<?php
			}
		}
}
function getitem($ntable,$nzd,$tjzd,$ntj)
{
	if($_GET[$tjzd]!="")
	{
		$sql="select ".$nzd." from ".$ntable." where ".$tjzd."='".$ntj."'";
		$query=mysql_query($sql);
		$rowscount=mysql_num_rows($query);
		if($rowscount>0)
		{
			
				echo "value='".mysql_result($query,0,0)."'";
			
		}
	}
}
function readzd($ntable,$nzd,$tjzd,$ntj)
{
	$sql="select ".$nzd." from ".$ntable." where ".$tjzd."='".$ntj."'";
		$query=mysql_query($sql);
		$rowscount=mysql_num_rows($query);
		if($rowscount>0)
		{
				echo mysql_result($query,0,0);
		}
}
function readzd2($ntable,$nzd,$tjzd,$ntj)
{
	$sql="select ".$nzd." from ".$ntable." where ".$tjzd."='".$ntj."'";
		$query=mysql_query($sql);
		$rowscount=mysql_num_rows($query);
		if($rowscount>0)
		{
				return mysql_result($query,0,0);
		}
}
function encos($nstr)
{
	if($nstr=="")
	{
		return "";
	}
	else
	{
		$nstr=str_replace("��","'",$nstr);
		$nstr=str_replace("��","<",$nstr);
		$nstr=str_replace("��",">",$nstr);
		$nstr=str_replace("��","%",$nstr);
		$nstr=str_replace("sp��","sp_",$nstr);
		$nstr=str_replace("xp��","xp_",$nstr);
		$nstr=str_replace("��","_",$nstr);
		$nstr=str_replace("��","+",$nstr);
		$nstr=str_replace("��",";",$nstr);
		$nstr=str_replace("��","/",$nstr);
		$nstr=str_replace("������","exec",$nstr);
		$nstr=str_replace("��������","declare",$nstr);
		
		return $nstr;
	}
}
?>