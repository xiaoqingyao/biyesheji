/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50160
Source Host           : localhost:3306
Source Database       : phpgrbkxt9086

Target Server Type    : MYSQL
Target Server Version : 50160
File Encoding         : 65001

Date: 2018-04-11 21:17:39
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `allusers`
-- ----------------------------
DROP TABLE IF EXISTS `allusers`;
CREATE TABLE `allusers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `pwd` varchar(50) DEFAULT NULL,
  `cx` varchar(50) DEFAULT '普通管理员',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of allusers
-- ----------------------------
INSERT INTO `allusers` VALUES ('2', 'hsg', 'hsg', '超级管理员', '2018-04-08 07:46:56');

-- ----------------------------
-- Table structure for `dx`
-- ----------------------------
DROP TABLE IF EXISTS `dx`;
CREATE TABLE `dx` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `leibie` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `content` text CHARACTER SET utf8,
  `addtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of dx
-- ----------------------------
INSERT INTO `dx` VALUES ('1', '个人简介', '<p>\r\n	sdgsdgsdgsd此处文字您自己修改11333xxxxxxxxxxxxxxxxxxxxxxx\r\n</p>\r\n<p>\r\n	本人简介：jofwegwgwo\r\n</p>\r\n<p>\r\n	此处内容请自己登陆后台修改即可gwegwegewgew\r\n</p>', '2018-04-08 07:46:56');
INSERT INTO `dx` VALUES ('2', '最新公告', '<p>\r\n	欢迎大家登陆我站，我站主要是为广大朋友精心制作的一个系统，希望大家能够在我站获得一个好心情，谢谢！\r\n</p>\r\n<p>\r\n	自强不息，海纳百川，努力学习！\r\n</p>', '2018-04-08 07:46:56');

-- ----------------------------
-- Table structure for `haoyouxinxi`
-- ----------------------------
DROP TABLE IF EXISTS `haoyouxinxi`;
CREATE TABLE `haoyouxinxi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zhanghao` varchar(50) DEFAULT NULL,
  `xingming` varchar(50) DEFAULT NULL,
  `xingbie` varchar(50) DEFAULT NULL,
  `fenzu` varchar(50) DEFAULT NULL,
  `tianjiaren` varchar(50) DEFAULT NULL,
  `beizhu` varchar(500) DEFAULT NULL,
  `issh` varchar(10) DEFAULT '否',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of haoyouxinxi
-- ----------------------------
INSERT INTO `haoyouxinxi` VALUES ('2', 'mygod', '陈德才', '男', '大学同学', '555', 'fewgew', '否', '2018-04-08 07:46:56');
INSERT INTO `haoyouxinxi` VALUES ('3', '555', '何升高', '男', '高中同学', 'hhrrr', 'gwegwe', '否', '2018-04-08 07:46:56');
INSERT INTO `haoyouxinxi` VALUES ('4', 'ggee', 'ggee', '男', '大学同学', '555', 'gewewhw', '否', '2018-04-08 07:46:56');
INSERT INTO `haoyouxinxi` VALUES ('5', 'xwxxmx', '吴江', '女', '初中同学', '555', 'fewgew', '否', '2018-04-08 07:46:56');
INSERT INTO `haoyouxinxi` VALUES ('6', 'ggee', 'ggee', '男', '家人', '555', 'aff', '否', '2018-04-08 07:46:56');
INSERT INTO `haoyouxinxi` VALUES ('7', '999', '小张', '男', '陌路', '555', 'ffsf', '否', '2018-04-08 07:46:56');
INSERT INTO `haoyouxinxi` VALUES ('8', '888', '李李', '男', '普通好友', '1', '123213', '否', '2018-04-09 03:53:26');

-- ----------------------------
-- Table structure for `liuyanban`
-- ----------------------------
DROP TABLE IF EXISTS `liuyanban`;
CREATE TABLE `liuyanban` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zhanghao` varchar(50) DEFAULT NULL,
  `zhaopian` varchar(50) DEFAULT NULL,
  `xingming` varchar(50) DEFAULT NULL,
  `liuyan` varchar(50) DEFAULT NULL,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `huifu` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of liuyanban
-- ----------------------------
INSERT INTO `liuyanban` VALUES ('28', 'htrhtrjr', '1', '何升高', 'jrtjtrjr', '2018-04-08 07:46:56', 'sdgdsgsd');
INSERT INTO `liuyanban` VALUES ('29', 'gregr', '1', '555', 'hrerhe', '2018-04-08 07:46:56', 'ewgwegew');
INSERT INTO `liuyanban` VALUES ('30', 'tyjt', '1', '何升高', 'jtyjty', '2018-04-08 07:46:56', 'fweegw');
INSERT INTO `liuyanban` VALUES ('33', '555', '1', '何升高', 'affda', '2018-04-08 07:46:56', 'gsgsgf');
INSERT INTO `liuyanban` VALUES ('34', '555', '1', '何升高', 'vb dgdgggdgdg', '2018-04-08 07:46:56', '12313123');
INSERT INTO `liuyanban` VALUES ('35', '1', '1', '1', '12312', '2018-04-09 03:52:49', null);

-- ----------------------------
-- Table structure for `pinglun`
-- ----------------------------
DROP TABLE IF EXISTS `pinglun`;
CREATE TABLE `pinglun` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `wenzhangID` varchar(255) CHARACTER SET gb2312 DEFAULT NULL,
  `pinglunneirong` varchar(1000) CHARACTER SET gb2312 DEFAULT NULL,
  `pinglunren` varchar(255) CHARACTER SET gb2312 DEFAULT NULL,
  `addtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `biao` varchar(50) CHARACTER SET gb2312 DEFAULT NULL,
  `pingfen` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of pinglun
-- ----------------------------
INSERT INTO `pinglun` VALUES ('1', '208', 'ewgwgwe', 'y6y6', '2018-04-08 07:46:56', 'xinwentongzhi', '1');
INSERT INTO `pinglun` VALUES ('2', '206', 'fewfwe', 'fsfd', '2018-04-08 07:46:56', 'xinwentongzhi', '1');
INSERT INTO `pinglun` VALUES ('3', '208', 'grerh', 'hrjre', '2018-04-08 07:46:56', 'xinwentongzhi', '1');
INSERT INTO `pinglun` VALUES ('4', '228', 'fewgwe', '555', '2018-04-08 07:46:56', 'xinwentongzhi', '1');
INSERT INTO `pinglun` VALUES ('5', '228', 'gwgwegew', 'bdbd', '2018-04-08 07:46:56', 'xinwentongzhi', '1');
INSERT INTO `pinglun` VALUES ('6', '218', 'grehrehe', 'bdbd', '2018-04-08 07:46:56', 'xinwentongzhi', '1');
INSERT INTO `pinglun` VALUES ('7', '228', 'wegwge', 'ge', '2018-04-08 07:46:56', 'xinwentongzhi', '1');
INSERT INTO `pinglun` VALUES ('8', '208', 'ewhwhw', 'fwgwgw', '2018-04-08 07:46:56', 'xinwentongzhi', '1');
INSERT INTO `pinglun` VALUES ('9', '217', 'htrhtrr', 'fwgwgw', '2018-04-08 07:46:56', 'xinwentongzhi', '1');
INSERT INTO `pinglun` VALUES ('10', '208', 'rejreje', 'ggee', '2018-04-08 07:46:56', 'xinwentongzhi', '1');
INSERT INTO `pinglun` VALUES ('11', '194', 'fadfd', '555', '2018-04-08 07:46:56', 'xinwentongzhi', '1');
INSERT INTO `pinglun` VALUES ('12', '236', 'afdfd', '555', '2018-04-08 07:46:56', 'xinwentongzhi', '1');
INSERT INTO `pinglun` VALUES ('13', '217', 'afddf', '555', '2018-04-08 07:46:56', 'xinwentongzhi', '1');
INSERT INTO `pinglun` VALUES ('14', '237', 'afddfafd', '555', '2018-04-08 07:46:56', 'xinwentongzhi', '1');
INSERT INTO `pinglun` VALUES ('15', '249', '1', '1', '2018-04-09 03:52:35', 'xinwentongzhi', '1');
INSERT INTO `pinglun` VALUES ('16', '230', '3213123123', '1', '2018-04-09 03:52:59', 'xinwentongzhi', '1');
INSERT INTO `pinglun` VALUES ('17', '252', '123123', '1', '2018-04-09 03:53:09', 'xinwentongzhi', '1');

-- ----------------------------
-- Table structure for `xinwentongzhi`
-- ----------------------------
DROP TABLE IF EXISTS `xinwentongzhi`;
CREATE TABLE `xinwentongzhi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `biaoti` varchar(500) CHARACTER SET gb2312 DEFAULT NULL,
  `leibie` varchar(50) CHARACTER SET gb2312 DEFAULT NULL,
  `neirong` text CHARACTER SET gb2312,
  `tianjiaren` varchar(50) CHARACTER SET gb2312 DEFAULT NULL,
  `addtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `shouyetupian` varchar(50) DEFAULT NULL,
  `dianjilv` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=253 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of xinwentongzhi
-- ----------------------------
INSERT INTO `xinwentongzhi` VALUES ('192', '今天心情好呀', '我的日志', 'hrehrehr<img src=\"http://localhost/kindeditor-4.1.10/plugins/emoticons/images/0.gif\" border=\"0\" alt=\"\" /><img src=\"http://localhost/kindeditor-4.1.10/plugins/emoticons/images/13.gif\" border=\"0\" alt=\"\" />', 'hsg', '2018-04-08 07:46:56', '', '1');
INSERT INTO `xinwentongzhi` VALUES ('193', '我终于毕业啦', '我的日志', 'rehrehrejee', 'hsg', '2018-04-08 07:46:56', '', '2');
INSERT INTO `xinwentongzhi` VALUES ('194', '老师你好', '我的日志', '<img src=\"http://localhost/kindeditor-4.1.10/plugins/emoticons/images/11.gif\" border=\"0\" alt=\"\" />', 'hsg', '2018-04-08 07:46:56', '', '6');
INSERT INTO `xinwentongzhi` VALUES ('195', '人口普查催热亲子鉴定 三次鉴定才确定生父(图)', '我的文章', '<TABLE style=\"cellSpacing: 0\" cellSpacing=0 cellPadding=0 align=center border=0>\r\n<TBODY>\r\n<TR>\r\n<TD align=middle>\r\n<TABLE style=\"cellSpacing: 0\" cellSpacing=0 cellPadding=0 border=0>\r\n<TBODY>\r\n<TR>\r\n<TD><IMG alt=\"\" src=\"http://img.zjol.com.cn/pic/0/04/01/82/4018258_714537.jpg\" align=middle></TD></TR></TBODY></TABLE></TD></TR>\r\n<TR>\r\n<TD style=\"FONT-SIZE: 12px\" align=middle scw_ig=\"yes\">&nbsp;</TD></TR></TBODY></TABLE><BR>\r\n<P>　　<STRONG>DNA人口普查催热亲子鉴定　</STRONG>　</P>\r\n<P>　　<STRONG>超生和非婚生子女办理入户前须出具亲子鉴定书 有鉴定机构10月份330宗鉴定中有近260例是为入户准备的</STRONG></P>\r\n<P>　　本报讯 （记者徐静 通讯员张淼）11月1日全国第六次人口普查正式开始，有政策规定，超生和非婚生子女在办理入户之前必须出具具有司法鉴定机构出具的亲子鉴定书，无形中催热了广州的亲子鉴定市场。</P>\r\n<P>　　南方医科大学法医鉴定中心相关负责人介绍，平常每个月接到亲子鉴定案子不到80宗，10月份接到的就将近330宗，最近中心接到的亲子鉴定案子激增4倍。</P>\r\n<P>　　<STRONG>南医鉴定中心接案增4倍</STRONG></P>\r\n<P>　　根据今年入户的全新规定，在办理超生和非婚生子女的户口之前，必须出具具有司法鉴定许可证的司法鉴定机构出具的亲子鉴定书，一时之间，亲子鉴定机构生意大增。</P>\r\n<P>　　南方医科大学司法鉴定中心相关负责人介绍，从9月起，来做亲子鉴定的就明显增多了。平常的时候每个月做的亲子鉴定为70多例，只有3~5例是为入户而做的，但10月份已经有近330宗要求亲子鉴定的，其中有近260例是要为入户做准备的。</P>\r\n<P>　　据介绍，目前广州市卫生部门向市民推荐了5家具有合法资质的亲子鉴定机构，包括南方医大司法鉴定中心、中山医司法鉴定中心、省妇幼、广医三院、广州市精神病院，不少深圳、珠海、东莞的市民也来广州做亲子鉴定。</P>\r\n<P>　　<STRONG>不要随便相信网上广告</STRONG></P>\r\n<P>　　记者在百度上输入“亲子鉴定”几个字，可以看到近八十页的链接，其中不少是亲子鉴定网站，还有的网站明目张胆地打着“司法亲子鉴定”的旗号，收费标准也比普通的亲子鉴定更高。</P>\r\n<P>　　南方医大法医鉴定中心相关负责人表示，亲子鉴定的技术并不复杂，随便一个生物公司都能做，关键是有些鉴定是司法上不认可的，有的网站不能通过司法鉴定，出具的检验报告上也没有司法专用章，“这样的鉴定报告在入户时是不被认可的，可能需要重新鉴定”。只有具有司法鉴定许可证的机构，才能办理官方认可的“司法亲子鉴定”。</P>\r\n<P>　　他建议要做亲子鉴定的市民，先要去地方司法厅网站上看看哪些机构是合法的，再去机构的网站上看有无实验室、固定的场地，最好能去实地考察一下。</P>\r\n<P>　　<STRONG>80后母亲鉴定委托增多</STRONG></P>\r\n<P>　　此外，南方医大法医鉴定中心的数据也显示，80后要求做亲子鉴定的案子正在逐年增多，甚至会占到亲子鉴定案件总数的一半。</P>\r\n<P>　　中心相关负责人表示， 社会越来越开放，这种情况也见怪不怪了。事实上，从2008年起，母亲作为委托人要求做亲子鉴定的案件数目开始大增，而在此之前主要是“父亲怀疑孩子不是自己的才来做鉴定”。同时，80后一代已成为亲子鉴定的“主力军”，在非人口普查时段，80后委托人占鉴定案件的一半。</P>\r\n<P>　　母亲确定孩子的父亲是谁时，一般会要求做胎儿鉴定。但负责人提醒，越早鉴定对胎儿影响越大，容易造成胎儿畸形。如果要做胎儿鉴定，要等到怀孕14周之后可用羊水做亲子鉴定。</P>\r\n<P>　　<STRONG>鉴定故事：</STRONG></P>\r\n<P><STRONG>　　检测3位男士确定孩子生父</STRONG></P>\r\n<P>　　最近，一位不到30岁的女士带着四五岁的孩子到鉴定中心，因为她弄不清孩子的父亲到底是谁。她填了两份鉴定表格，原来要在两位男士间确定身份。她带着孩子和男士来检测，同时还有另外一位男士抽过的烟头样本做检测。结果，检测证明这两位男士都不是孩子的父亲。正常情况下，应该有一个是孩子的父亲，很少有两个都不是的情况。</P>\r\n<P>　　三个月后，这位女士又提供了一位男士的毛发样本。经过毛发样本比对，判断是孩子的生父。鉴定中心工作人员说，到底是什么情况也不好问，不过很可能是在怀上这个小孩的那段时间这位女士与多位男士发生过性关系，搞到自己都弄不清楚了。</P>\r\n<P>　<STRONG>　不信鉴定结果要亲自监督检测</STRONG></P>\r\n<P>　　王丽（化名）怎么看都觉得孩子与自己和丈夫长得不像，担心当初在医院分娩后医生给抱错了，就到鉴定中心做亲子鉴定。鉴定结果，这个孩子确实是他和丈夫的亲生儿子。但王丽在这件事情上疑心很重，仍然觉得结果不可靠，先后在多家鉴定中心做鉴定，结果都一样。</P>\r\n<P>　　这可是一件让她焦心的事情。为此，王丽晚上经常失眠，即使丈夫早已相信孩子是两个人亲生的，并不断劝说她，也丝毫没能打消她的顾虑。后来，王丽来到南方医科大学鉴定中心。鉴定中心获悉王丽的心理后，决定采用盲测，也就是不看以前的鉴定书意见。等鉴定完后，她再进行数据的比对。当然，数据与其他鉴定中心的一致。</P>\r\n<P>　　但王丽还是怀疑，一个月后，她又来到鉴定中心。鉴定中心的工作人员建议她看看是否有必要做心理治疗。不过，王丽表示，她已经做了一段时间心理治疗了。</P>\r\n<P>　　王丽情绪低落，始终放不下这个问题，鉴定中心告诉她整个检测过程，告知其中绝对不会作假，但王丽提出要亲自监督检测。这种要求是以前从来没有过的。不过，鉴定中心也同意了，在周末对这3个人单独做检测，共用时间6个小时，王丽一直在旁观看。这次数据出来后，王丽此后再也没有找过鉴定中心。</P><!--function: content() parse end  0ms cost! -->', 'hsg', '2018-04-08 07:46:56', 'uploadfile/1340069838pb96.jpg', '1');
INSERT INTO `xinwentongzhi` VALUES ('196', '钱库派出所通过路面监控查处一起砸车盗窃车内物品案件', '我的文章', '&nbsp;&nbsp;&nbsp; 11月21日，钱库派出所接报警称：2011年11月21日3时许，受害人林某停放在浙江省温州市苍南县钱库镇环城北路前的一辆黑色尼桑牌的车玻璃被砸，驾驶后座包内的1000元人币及一只雷达牌手表和身份证被盗，损失总价值21000元。<BR>&nbsp;&nbsp;&nbsp; 钱库派出所民警立即调查取证，通报路面巡逻人员，加强巡逻。并通过前期排摸与原有信息分析，在犯罪分子可能出没时间、地点，蹲点守候，终于在2011年11月21日3时30分在苍南县钱库镇犯罪嫌疑人谈某、石某，经查，犯罪嫌疑人员谈某、石某先后在灵溪、龙港、钱库、宜山等地盗窃车内物品十余次，盗窃物品价值约为5万元。<BR>&nbsp;&nbsp;&nbsp; 现该嫌疑人员谈某、石某已被钱库派出所依法刑事拘留，案件还在进一步审理中。<BR>', 'hsg', '2018-04-08 07:46:56', 'uploadfile/13400699440gw0.jpg', '1');
INSERT INTO `xinwentongzhi` VALUES ('197', '我市出台《市区整治和查处违法建筑若干规定》', '我的文章', '&nbsp;&nbsp;&nbsp; 5月4日，市长赵一德主持召开第51次市政府常务会议，审议并原则通过《温州市区整治和查处违法建筑若干规定》（以下简称《规定》），力求从源头、法规、制度、体制机制上有效保障拆除历史违章，遏制新违章。 \r\n<P>　　在我市，已建成的违法建筑量大面广，现行的违法建设禁而不止、屡拆屡建、越拆越多，查控违法建设的形势非常严峻，并呈现区域性突击建设、地方势力（老人协会等）成规模建设、群体性阻碍拆违等态势。而我市传统的拆违方式和拆违体制，已脱离当前实际，查控违法建设工作面临许多新问题、新挑战。</P>\r\n<P>　　《规定》对已建成违法建筑明确要求全面查处、重点整治、分类处置；对现行违法建设明确了防控查处的机制、责任、程序，设定了信息共享、日常巡查、查处流程、首查责任和案件移送等制度和机制。同时明确属地管理、分工协办的查控体制，各区、镇政府为本行政区域主要责任主体，各功能区管委会、街道办事处受委托作为本行政区域主要责任主体，城管与执法和国土资源部门为执法主体，其他各职能部门是违法用地和建设的共同责任主体。</P>\r\n<P>　　《规定》要求以考核考绩和纪律追究推进工作落实。建立定期监督制度，责任到人，考绩追责。其中，最主要的是日常拆违情况核查，每月通报排名公布以及市考绩办、督查室相应的绩效考核追责。明确公职人员的当事人违纪责任追究。将公职人员、党员、干部、人大代表、政协委员参与违法建设纳入“六必拆”的同时，《规定》还提出对他们参与的违法建设，要限期自行拆除，并由纪委监察部门约谈告诫，严重的给予纪律和行政处分。《规定》鼓励自行整改，减少拆违阻力，降低拆违成本，以强拆促自拆，加快推进速度，实现良性循环。</P>\r\n<P>　　昨天的会议还审议并原则通过了《乐清市瑞安市永嘉县平阳县文成县都市功能区建设方案》、《温州市区国有土地上房屋征收与补偿实施办法（试行）》、《关于加快对转而未供和村二三产返回闲置土地优化利用的若干意见》、《温州市创建省级环境保护模范城市规划》、《关于加快水利改革发展的实施意见》、《关于加快推进供销合作社改革发展的实施意见》和《温州市劳动模范评选和管理工作暂行办法》，听取了温州大学城市学院规范设置用地产权调整意见和关于温州市教育发展与体育发展两个投资集团有限公司组建方案的汇报。</P>\r\n<P>　　副市长孟建新、徐育斐、周少政、章方璋、仇杨均、陈浩、任玉明，市政府秘书长詹永枢出席会议。</P>\r\n<P>　　（记者 吴勇 尤海峰）</P>', 'hsg', '2018-04-08 07:46:56', 'uploadfile/1340069970gp0a.jpg', '1');
INSERT INTO `xinwentongzhi` VALUES ('198', '钱库派出所成功查破一起特大赌博案件', '我的文章', '<DIV>&nbsp;&nbsp;&nbsp;&nbsp; 7月30日上午，钱库派出所因前期缜密侦察的基础，主动出击，在黄判桥村黄龙江北路221号当场查获一起赌博案件，现场抓获参赌人员30余人，现场缴获赌资4万余元，经审查，成功查破一起特大赌博案件，一举摧毁了盘据在钱库、金乡、巴曹等地的赌博窝点10余处。</DIV>\r\n<DIV>&nbsp;&nbsp;&nbsp;&nbsp; 对李某等9人涉嫌开设赌场，依法予以刑事拘留，对吴某等40名参赌人员依法予以治安拘留的处罚。该案的成功查破，进一步遏制了钱库辖区赌博警情高发态势，有效地净化了钱库辖区的社会治安环境，为派出所下步开展“禁赌风暴”专项行动起好头，开好步。(派出所)</DIV>', 'hsg', '2018-04-08 07:46:56', 'uploadfile/1340070002x47w.jpg', '1');
INSERT INTO `xinwentongzhi` VALUES ('199', '朱贤良赴泰顺督查人口计生工作', '我的文章', '&nbsp;&nbsp;&nbsp;&nbsp; 6月30日，市委副书记朱贤良率队来到泰顺县开展人口计生工作专项督查。朱贤良在督查中强调，各地各有关部门要进一步强化国策责任意识，夯实基础，狠抓落实，加大力度积极创优，为推进我市人口计生工作作出新的更大贡献。 \r\n<P>　　朱贤良说，尽管工作努力，成绩值得肯定，但由于存在历史旧债没有及时处理到位、工作力度减弱、统计质量低、重点难点突破不力等问题，今年泰顺县的人口计生工作还不稳定，需要引起高度重视。下一步，要坚持常态管理均衡发展，扎实推进各项工作措施落到实处。要切实提高对人口计生工作重要性的认识，着力形成推进人口常态发展的工作机制，坚持建立领导重视的责任体系，坚持形成综合治理的工作格局，坚持强化绩效挂钩的用人导向。要突出解决影响工作水平提升的重点问题，紧盯性别比偏高问题的治理，高度重视社会抚养费征收工作，强化流动人口计生管理服务的研究。要加大力度推进“强基创优”工程的有效落实，提高干部认识，实施后进转化，推动村级自治，落实责任捆绑。要提升服务质量，营造浓厚氛围，转变干部作风，努力提供让人民群众满意的优质服务。</P>\r\n<P>　　（记者 陈里雅）</P></FOUNDER-CONTENT>\r\n<META name=ContentEnd><!--ZJEG_RSS.content.end--><!--<$[信息内容]>end-->', 'hsg', '2018-04-08 07:46:56', 'uploadfile/1340070029dc64.jpg', '2');
INSERT INTO `xinwentongzhi` VALUES ('200', '吕祖善发表电视讲话动员人口普查工作', '我的文章', '<P>　　从11月1日至11月10日，全国第六次人口普查进入入户登记阶段。全省50万名普查工作人员将走进千家万户进行现场登记。为动员全省各界人士积极配合人口普查，省委副书记、省长吕祖善发表电视讲话。 <BR>　　吕祖善指出，人口普查既是一项重大的国情国力调查，也是了解、掌握省情省力的基础工作，对于科学制定国民经济和社会发展规划，统筹安排人民群众物质文化生活，促进经济社会持续平稳健康发展，保障和改善民生，具有十分重要的意义。 </P>\r\n<P>　　第六次人口普查是在我省经济持续快速发展、社会结构不断调整、人口状况有很大改变的形势下进行的。与前五次相比，情况更复杂、任务更艰巨、时间更紧迫。吕祖善强调，全省各级政府和各普查机构要进一步增强责任感和使命感，对普查的各项准备工作进行一次再检查、再落实，确保每个环节都不发生疏漏。 </P>\r\n<P>　　吕祖善要求，各有关部门及驻浙单位要积极配合，支持普查工作人员做好普查工作。全省每个公民以及在浙江居住的港澳台和外籍人士，要积极支持和配合人口普查，准确申报每一个普查项目，确保我省人口普查现场登记顺利完成。 <BR>&nbsp;<BR>&nbsp;&nbsp; <BR>&nbsp;<BR></P>', 'hsg', '2018-04-08 07:46:56', '', '1');
INSERT INTO `xinwentongzhi` VALUES ('203', '市消保委突击检查快递业', '我的文章', '<DIV id=zoom>\r\n<TABLE align=center>\r\n<TBODY>\r\n<TR>\r\n<TD><IMG src=\"http://www.wenzhou.gov.cn/picture/0/110223060703169.jpg\" border=0></TD></TR></TBODY></TABLE><!--<$[信息内容]>begin--><!--ZJEG_RSS.content.begin-->\r\n<META name=ContentStart>\r\n<P align=center>　　　<FONT face=楷体_GB2312 color=#004080>快递时被摔坏的酒杯。</FONT></P>\r\n<P>　　快递6只酒杯，收到后有5只是摔坏的。近日，市消保委联合邮政、工商、物价等部门及媒体深入快递业进行明察暗访，发现我市部分快递企业在整理快件时所采用的方式已近“暴力”。 </P>\r\n<P>　　<STRONG>投诉</STRONG></P>\r\n<P><STRONG>　　去年较2009年增30.8%</STRONG></P>\r\n<P>　　去年8月，新《邮政法》实施后，快递行业门槛提高，经营快递需先取得《快递业务经营许可证》。从此，快递业进入洗牌阶段。据市邮政部门工作人员介绍，去年8月前，我市有快递企业100多户，洗牌后取得经营许可的快递企业目前只有60多户。</P>\r\n<P>　　尽管如此，快递投诉却未减反增。市工商局“12315”中心提供的数据显示，去年，该中心共接到快递投诉527起，较2009年的403起增加30.8%。今年1月1日以来，我市已接到快递投诉61起。消费者在投诉时反映最多的是，快递过程中物品丢失、缺少、损坏，到达时间延误，不履行赔偿责任或赔偿不合理等。</P>\r\n<P>　　好端端的物品在快递时为什么会损坏、丢失？</P>\r\n<P>　<STRONG>　暗访</STRONG></P>\r\n<P><STRONG>　　快递分区几乎靠扔</STRONG></P>\r\n<P>　　2月17日，市消保委就此组织工作人员，以消费者的身份深入市区几家快递企业进行暗访。</P>\r\n<P>　　在圆通速递温州分公司，参与暗访的工作人员以寄件名义顺利进入快件分流操作台。据他们描述，当时该点的几名工人正将快件进行分类，场景挺“暴力”。看过快递单后，工人们随手就将快件往摆放在四周的半封闭铁笼中扔。铁笼按区域摆放，离工人远的有6米多，近的也有2米。因为熟练，工人们很少将快件丢出笼外。</P>\r\n<P>　　在顺丰速递温州分公司，参与暗访的工作人员试图进入操作台被拒绝，只能通过寄件来侧面测试是否存在“暴力”分拣。他们从这里寄出一只花瓶和一部手机，一天后，花瓶和手机完好无损地到达收件人手中。</P>\r\n<P>　　在韵达快递温州分公司，参与暗访的工作人员采取同样的方法，从这里寄出6只葡萄酒高脚杯。受理业务后，收件员特别在杯子内外加了报纸进行保护。但是，杯子被送到苍南龙港后，仍被摔坏了5只。受理此业务的业务员感叹，自己虽然做到位，但是快递环节很多，不知道在哪会被“暴力”，真是防不胜防。</P>\r\n<P>　<STRONG>　明察</STRONG></P>\r\n<P><STRONG>　　管理疏忽快件易被偷</STRONG></P>\r\n<P>　　2月22日下午，市消保委就此联合邮政、工商、物价等部门对位于市区南白象、汤家桥的快递企业进行突击检查。记者随一组执法人员前往南白象。</P>\r\n<P>　　在圆通，大门敞开，近千平方米的快件储藏库中竟无一人，检查组进去约5分钟后才有一名工作人员出来。记者问及为何管理如此疏忽，这人解释，下午人少，只有两个人在看管仓库，到晚上才会来人对快件进行分流。</P>\r\n<P>　　在韵达，执法人员直接拿出被摔坏的酒杯讨说法。该快递企业负责人看过快递单后，自己找出了问题??单上的寄件地址咋是“浙江某某科技有限公司”？收件员解释，是他不小心将消费者的单子弄丢了，所以就用了一张用过的单子填写了原先的信息。至于，为什么杯子会被摔坏，韵达快递解释，他们已经很小心，可能是收件方出了问题。对此，他们表示愿意赔偿。</P>\r\n<P>　　接下来，市消保委将召集相关快递企业就存在的问题进行座谈。（记者 曾云毕）</P>\r\n<META name=ContentEnd><!--ZJEG_RSS.content.end--><!--<$[信息内容]>end--></DIV>', 'hsg', '2018-04-08 07:46:56', '', '1');
INSERT INTO `xinwentongzhi` VALUES ('204', '朱贤良在我县督查信访维稳工作时强调：确保社会稳定 营造和谐环境', '我的文章', '&nbsp;&nbsp;&nbsp; 3月3日消息：昨天下午，市委副书记朱贤良来我县就信访维稳工作展开督查。他强调，各地各有关部门务必要增强政治意识、大局意识、忧患意识和责任意识，把各项有效措施落到实处，确保社会大局持续稳定，为全国“两会”的胜利召开营造和谐的环境。县领导林晓峰、林万乐、黄锦耀、胡长虹、蒋荣国参加汇报会。\r\n<P>&nbsp;&nbsp;&nbsp; 督查组听取了情况汇报，并对我县在工作中存在的一些问题和不足进行了细致的分析，提出了具体意见。朱贤良对我县近段时间的信访维稳工作给予充分肯定。据了解，去年以来，我县积极有效地处置了涉及宗教纠纷、重点工程建设纠纷、海域权属纠纷、“7?25”重大交通事故等多起群发性、突破性事件；排查不稳定因素435起，成功化解418起，较好完成了世博安保、亚运安保和各级“两会”信访维稳纠纷，实现了“总量减少、敏感时期择机信访减少、越级信访减少、积案存量减少”的信访工作目标，信访工作被省委、省政府评为年度优秀。</P><!--advertisement code begin--><!--advertisement code end-->\r\n<P>&nbsp;&nbsp;&nbsp; 朱贤良指出，下一步，苍南还应切实认清国内外形势，结合地方实际和当前面临的新挑战，始终把握对当前信访维稳形势的正确判断。特别是要根据中央和省委提出的“四防止、两确保”的工作目标，积极应对敏感问题，深化苗头隐患排查，加强重点人员稳控，加大责任落实力度，切实维护正常信访秩序。要继续找准工作定位，始终保持奋发向上的良好工作态势。要深入推进社会矛盾化解，按照“应评尽评”的要求，对重大事项全面进行社会稳定风险评估，扎实推进信访积案和不稳定因素化解，以开展“大调解”工作体系构建试点为契机，狠抓制度出台、内部规范、硬件完善等各项工作落实，努力为全市提供经验。同时要深入研究加强和创新社会管理工作，不断强化基层基础建设，切实提升平安创建水平。</P>\r\n<P>&nbsp;&nbsp;&nbsp; 朱贤良强调，当前国内外形势复杂，乡镇撤扩并和村级组织换届又给维稳工作带来了新挑战。各级各部门要以“全省领先、全国一流”为标杆，结合年初部署的信访维稳各项任务，狠抓各项工作落实，确保“两会”期间政治社会的稳定和谐局面。要及早落实今年平安创建措施，巩固“创安护鼎”的成果，认真迎检，为全县信访维稳工作打下良好基础，为苍南经济社会又好又快发展提供强大保障。（记者 方耀星）</P>', 'hsg', '2018-04-08 07:46:56', '', '1');
INSERT INTO `xinwentongzhi` VALUES ('205', '我市农村指导员“互看互学互查”找差距', '我的文章', '&nbsp;&nbsp;&nbsp; 本月16日到26日，我市在各县（市、区）之间开展农村工作指导员“互看互学互查”活动。此次活动除组织各地农指员相互学习找差距外，还发动他们引导各地百姓参与“六城联创”。 \r\n<P>　　此次活动把全市按地域分为两片，北片包括市区三区、乐清市、永嘉县、洞头县；其余县、市为南片。全市统一组织两片区各县（市、区）农指办负责人、市派各联络组组长，进行异地查看和工作交流，听取所派驻乡镇、村“两委”对指导员的评价，以及各县（市、区）指导员半年度工作汇报。</P>\r\n<P>　　该活动还要求，下阶段各地农指员们要把工作重点放在发动基层村民，协助我市完成“六城联创”。比如针对“四大战役”和“四大整治”，所驻村如已列入全市1000个行政村绿化工程的，农指员要因地制宜引导村民在房前屋后种植乡土树木；所驻村已列入“城中村”改造项目的，农指员要协助村“两委”做好资产清理、房屋拆迁、工程建设等工作，使有关建设项目按规定时限完成；所驻村如有古村落、古民居等历史文化遗产的，农指员要引导村“两委”制定保护开发规划，发动村民自觉保护这些遗产。温瑞塘河周边的派驻村，农指员要摸清村内污染源，举报、打击废水泥浆偷漏排、涉河违法搭建等危害水环境行为。</P>', 'hsg', '2018-04-08 07:46:56', '', '3');
INSERT INTO `xinwentongzhi` VALUES ('207', '县领导在钱库马站等地督查“绿美”活动时要求：坚定信心攻坚克难 科学推进力出精品', '我的文章', '<P align=center><IMG style=\"BORDER-LEFT-COLOR: #000000; BORDER-BOTTOM-COLOR: #000000; BORDER-TOP-COLOR: #000000; BORDER-RIGHT-COLOR: #000000\" src=\"/upload/editorfiles/2011.4.1_9.41.53_3294.jpg\" border=0><BR></P>\r\n<P align=center><IMG style=\"BORDER-LEFT-COLOR: #000000; BORDER-BOTTOM-COLOR: #000000; BORDER-TOP-COLOR: #000000; BORDER-RIGHT-COLOR: #000000\" src=\"/upload/editorfiles/2011.4.1_9.42.53_1487.jpg\" border=0></P>\r\n<P align=center><BR></P>\r\n<P align=center><IMG style=\"BORDER-LEFT-COLOR: #000000; BORDER-BOTTOM-COLOR: #000000; BORDER-TOP-COLOR: #000000; BORDER-RIGHT-COLOR: #000000\" src=\"/upload/editorfiles/2011.4.1_9.43.7_7859.jpg\" border=0><BR><BR><BR>&nbsp;&nbsp;&nbsp; 今昨两日，县委常委、宣传部长戴嘉宝带领县文明办、林业局、清洁办负责人在钱库、马站等中心镇督查“绿色苍南，美丽家园”活动时指出，当前开展文明城镇创建领导重视，群众支持，时机成熟，钱库、马站等中心镇要抓住机遇，坚定信心，突出重点，务求实效，体现特色，切实把文明城镇创建提升到一个新的水平，改善民生，惠泽百姓。</P>\r\n<P>&nbsp;&nbsp;&nbsp; 昨日，戴嘉宝等一行在钱库镇党委、政府主要负责人的陪同下先后前往钱库大道、桐桥村苗圃基地、河家埭村、章均?村入口处以及有关垃圾整治点察看。在占地面积150亩的桐桥村苗圃基地，看到满园苗圃生机盎然，戴嘉宝甚感欣慰，要求进一步抓好基地建设，为“绿色苍南、美丽家园”活动作贡献。在河家埭村和章均?村检查清洁家园和绿化工作时，戴嘉宝指出，新农村建设要科学规划、突出特色，力求上档次、有品味，凸显江南水乡特色，彰显历史文化底蕴。</P><!--advertisement code begin--><!--advertisement code end-->\r\n<P>&nbsp;&nbsp;&nbsp; 随后，戴嘉宝等一行具体听取了钱库镇关于文明城镇创建工作汇报，对该镇近段时间的绿化和垃圾乱点整治表示肯定。在谈到下一步的文明城镇创建时，他指出，当前一些地方工业化步伐较快，城市化水平偏低，尤其是城镇脏乱差现象明显。文明创建涉及城市建设和发展的方方面面，文明城镇是所有城市金名片中含金量最高的，未来城市之间的竞争主要是环境的竞争，人的综合素质的竞争。他着重指出，以“绿色苍南、美丽家园”活动为总载体的文明城镇创建是长期的，要坚定信心，形成共识。钱库成为中心镇后，要抓住时机，改善环境，惠泽百姓。钱库有一定的历史文化底蕴，群众基础较好，对文明创建要有决心和恒心，特别是市民素质的提升要有一个长期的过程，一定要坚持不懈地抓实抓好。</P>\r\n<P>&nbsp;&nbsp;&nbsp; 戴嘉宝强调，文明城镇创建要突出重点，攻坚克难。要打好交通整治攻坚战，以优美环境塑造人；要打好道德实践持久战，以文明素质提升人；要打好城市管理阵地战，以规范的制度管理人；要打好基层基础主动战，上下联动共创文明。他最后要求钱库镇在文明城镇创建中进一步加强组织领导，明确职责，务求实效；要广泛宣传动员，形成浓厚创建氛围；督查考核要落实到位，力争在文明创建中显特色、出精品。</P>\r\n<P>&nbsp;&nbsp;&nbsp; 今天上午，戴嘉宝带领县文明办、林业局有关负责人前往马站镇督查“绿色苍南、美丽家园”活动。他详细察看了该镇清洁家园示范村中魁村、顶魁村和棋盘村，具体听取了当地有关情况汇报，对相关绿化和保洁工作进行指导，要求出亮点，出品牌，提升文化品位。随后，他着重听取了马站镇关于绿化工作汇报，对该镇把11公里长的乡村道路两侧进行绿化予以肯定。</P>\r\n<P>&nbsp;&nbsp;&nbsp; 戴嘉宝在督查中指出，马站镇要抓住机遇，扬长避短，以文明城镇创建科学推进城乡统筹发展，既要注重城镇基础设施建设和维护，又要常抓人文环境的优化，不断提高市民综合素质，促进文明创建上档次、有品位。戴嘉宝最后要求马站镇切实加强领导，突出重点，深入宣传发动，抓好督查考核，在“绿色苍南、美丽家园”活动中出精品，出典型，让马站的环境更优更美。（记者 郑法群）</P>', 'hsg', '2018-04-08 07:46:56', '', '2');
INSERT INTO `xinwentongzhi` VALUES ('208', '辽宁坠机事件已查明', '我的文章', '新华网北京８月１９日电 记者１９日从有关部门了解到，经有关部门调查，８月１７日在辽宁抚顺失事的朝鲜军用飞机系因机械故障、迷失航向，误入中国境内坠毁。中朝双方已就有关善后处理达成一致。朝方就这一意外事件向中方表示了歉意。 <!--advertisement code begin--><!--advertisement code end--><!--function: content() parse end  0ms cost! -->', 'hsg', '2018-04-08 07:46:56', '', '12');
INSERT INTO `xinwentongzhi` VALUES ('216', '个人写真', '图片分享', '<img src=\"/kindeditor-4.1.10/php/../attached/image/20150314/20150314061720_73506.jpg\" alt=\"\" /><img src=\"/kindeditor-4.1.10/php/../attached/image/20150314/20150314061720_94674.jpg\" alt=\"\" /><img src=\"/kindeditor-4.1.10/php/../attached/image/20150314/20150314061720_33299.gif\" alt=\"\" /><img src=\"/kindeditor-4.1.10/php/../attached/image/20150314/20150314061720_30006.jpg\" alt=\"\" /><img src=\"/kindeditor-4.1.10/php/../attached/image/20150314/20150314061720_41382.jpg\" alt=\"\" width=\"500\" height=\"333\" title=\"\" align=\"\" /><img src=\"/kindeditor-4.1.10/php/../attached/image/20150314/20150314061721_36446.jpg\" alt=\"\" />', 'hsg', '2018-04-08 07:46:56', 'uploadfile/1426313853bfat.jpg', '13');
INSERT INTO `xinwentongzhi` VALUES ('217', '户外风景', '图片分享', '<img src=\"/kindeditor-4.1.10/php/../attached/image/20150314/20150314061759_67205.jpg\" alt=\"\" width=\"500\" height=\"375\" title=\"\" align=\"\" /><img src=\"/kindeditor-4.1.10/php/../attached/image/20150314/20150314061759_81496.jpg\" alt=\"\" width=\"500\" height=\"375\" title=\"\" align=\"\" /><img src=\"/kindeditor-4.1.10/php/../attached/image/20150314/20150314061759_74964.jpg\" alt=\"\" width=\"500\" height=\"368\" title=\"\" align=\"\" /><img src=\"/kindeditor-4.1.10/php/../attached/image/20150314/20150314061759_61720.jpg\" alt=\"\" width=\"500\" height=\"312\" title=\"\" align=\"\" /><img src=\"/kindeditor-4.1.10/php/../attached/image/20150314/20150314061759_64656.jpg\" alt=\"\" width=\"500\" height=\"256\" title=\"\" align=\"\" /><img src=\"/kindeditor-4.1.10/php/../attached/image/20150314/20150314061759_17080.jpg\" alt=\"\" width=\"500\" height=\"375\" title=\"\" align=\"\" />', 'hsg', '2018-04-08 07:46:56', 'uploadfile/14263138925kcv.jpg', '26');
INSERT INTO `xinwentongzhi` VALUES ('218', '影片收藏', '图片分享', '<p style=\"text-align:center;\">\r\n	<img src=\"/kindeditor-4.1.10/php/../attached/image/20150314/20150314061855_97717.jpg\" alt=\"\" />\r\n</p>\r\n<p style=\"text-align:center;\">\r\n	<img src=\"/kindeditor-4.1.10/php/../attached/image/20150314/20150314061855_92889.jpg\" alt=\"\" />\r\n</p>\r\n<p style=\"text-align:center;\">\r\n	<img src=\"/kindeditor-4.1.10/php/../attached/image/20150314/20150314061855_64299.jpg\" alt=\"\" />\r\n</p>\r\n<p style=\"text-align:center;\">\r\n	<img src=\"/kindeditor-4.1.10/php/../attached/image/20150314/20150314061855_18349.jpg\" alt=\"\" />\r\n</p>\r\n<p style=\"text-align:center;\">\r\n	<img src=\"/kindeditor-4.1.10/php/../attached/image/20150314/20150314061855_53536.jpg\" alt=\"\" />\r\n</p>\r\n<p style=\"text-align:center;\">\r\n	<img src=\"/kindeditor-4.1.10/php/../attached/image/20150314/20150314061855_99013.jpg\" alt=\"\" />\r\n</p>', 'hsg', '2018-04-08 07:46:56', 'uploadfile/14263139529wcq.jpg', '14');
INSERT INTO `xinwentongzhi` VALUES ('219', '晚会活动', '图片分享', '<p>\r\n	<img src=\"/kindeditor-4.1.10/php/../attached/image/20150314/20150314062804_46675.gif\" alt=\"\" />\r\n</p>\r\n<p>\r\n	<img src=\"/kindeditor-4.1.10/php/../attached/image/20150314/20150314062804_52525.jpg\" alt=\"\" />\r\n</p>\r\n<p>\r\n	<img src=\"/kindeditor-4.1.10/php/../attached/image/20150314/20150314062804_80087.jpg\" alt=\"\" width=\"500\" height=\"335\" title=\"\" align=\"\" />\r\n</p>', 'hsg', '2018-04-08 07:46:56', 'uploadfile/1426314512trha.jpg', '11');
INSERT INTO `xinwentongzhi` VALUES ('220', '关于公民旁听温州市第十一届人大常委会第二十九次会议的公告', '热门信息', '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 温州市第十一届人大常委会第六十二次主任会议决定，市第十一届人大常委会第二十九次会议允许公民旁听。现将有关事项公告如下： \r\n<P>　　一、会议时间：2010年12月8日上午8:30开始，会期2天。本次常委会安排公民旁听第一、二次全体会议，时间分别是12月8日上午8:30－11:30、12月9日上午10:00－11:30。</P>\r\n<P>　　二、会议地点：温州市行政管理中心人大办公大楼一楼常委会会议厅。</P>\r\n<P>　　三、会议主要建议议程：（一）听取和审议我市“十一五”规划纲要实施和“十二五”规划纲要编制情况的报告；（二）听取和审议市政府关于温州市2009年市级财政预算执行及其他财政收支情况审计报告整改意见落实情况的报告；（三）听取和审议市政府关于市十一届人大五次会议代表建议办理工作情况的报告；（四）听取和审议市政府关于落实水污染防治“一法两条例”执法检查审议意见情况的报告；（五）听取和审议市政府关于2010年温州市地方政府债券预算调整情况的报告；（六）审议市政府关于落实2009年政府投资项目计划执行和2010年政府投资项目计划安排审议意见情况的报告；（七）审议市政府关于落实食品安全工作审议意见情况的报告；（八）审议市中级法院关于落实行政审判工作审议意见情况的报告；（九）其他事项。</P>\r\n<P>　　四、旁听本次人大常委会会议的公民人数不超过15名。凡是户籍在温州市或在温州市居住满1年，年满18周岁，具有完全民事行为能力的中国公民，都可以提出旁听市第十一届人大常委会第二十九次会议的申请。依法被限制人身自由或剥夺政治权利的除外。</P>\r\n<P>　　五、申请旁听本次会议的公民，先进行电话预约登记。预约登记电话：88969828，预约登记时间：12月1日至2日上午9:00－11:30，下午2:30－5:00。</P>\r\n<P>　　六、市人大常委会办公室将根据公民预约登记及组织推荐等情况，确定旁听本次会议的公民名单，并通知旁听公民本人持身份证及其他有效证件，到市人大常委会办公室办理正式申请手续，领取旁听证及会议资料。</P>\r\n<P>　　七、请参加旁听的公民按通知的时间、地点和要求准时到会，并遵守会场纪律。</P>\r\n<P>　　特此公告</P>\r\n<P align=right>　　温州市人大常委会办公室</P>\r\n<P align=right>　　二O一O年十一月二十九日</P>', 'hsg', '2018-04-08 07:46:56', 'uploadfile/1340069838pb96.jpg', '1');
INSERT INTO `xinwentongzhi` VALUES ('221', '关于2011公务员报考注册报名1月12日再开放一天的紧急通知', '热门信息', '<DIV align=center><B>紧 急&nbsp; 通&nbsp; 知</B><B></B></DIV>\r\n<DIV align=left><B></B><B></B>&nbsp;</DIV>\r\n<DIV align=left><B>&nbsp;&nbsp; </B>由于部分报考浙江省各级机关公务员的考生因网络阶段性拥堵未能完成报名或注册，经研究决定,浙江省公务员考试录用系统自1月12日0时起至1月12日24时再开放一天，请报考人员抓紧时间完成注册并报名。</DIV>\r\n<DIV align=left>&nbsp;</DIV>\r\n<DIV align=center>省委组织部公务员管理处&nbsp;&nbsp;&nbsp; 省公务员局考试录用处</DIV>\r\n<DIV align=center>&nbsp;</DIV>\r\n<DIV align=right>二?一一年一月十一日</DIV>', 'hsg', '2018-04-08 07:46:56', 'uploadfile/13400699440gw0.jpg', '2');
INSERT INTO `xinwentongzhi` VALUES ('222', '浙江省人民政府关于华乃强等任职的通知', '热门信息', '<TABLE height=600 cellSpacing=1 cellPadding=0 width=\"90%\" align=center border=0 valigh=\"top\">\r\n<TBODY>\r\n<TR>\r\n<TD style=\"FONT-SIZE: 12px; COLOR: #333333\" align=middle>浙政干〔2010〕32号</TD></TR>\r\n<TR>\r\n<TD id=fontzoom style=\"FONT-SIZE: 15px; COLOR: #333333; LINE-HEIGHT: 24px\" vAlign=top>\r\n<DIV id=printdiv name=\"printdiv\"><!--ZJEG_RSS.content.begin-->\r\n<P>省政府研究决定：<BR>　　华乃强任浙江省公安厅巡视员；<BR>　　章润根任浙江省省级机关事务管理局巡视员；<BR>　　李刚任浙江省民政厅副巡视员；<BR>　　黄圣方任浙江省体育局副巡视员；<BR>　　黄中任浙江省统计局副巡视员；<BR>　　桑士达任浙江省人民政府研究室副巡视员；<BR>　　张海潍任浙江省人民政府金融工作办公室副巡视员。 \r\n<P>\r\n<P>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;二○一○年七月十六日 \r\n<P>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; （此件公开发布）</P></DIV></TD></TR></TBODY></TABLE>', 'hsg', '2018-04-08 07:46:56', 'uploadfile/1340069970gp0a.jpg', '1');
INSERT INTO `xinwentongzhi` VALUES ('223', '六个县处级领导职位发布空缺预告', '热门信息', '&nbsp;&nbsp;&nbsp; 从市委组织部获悉，我市发布6个县处级领导职位空缺预告，今起接受各界推荐提名。这是继今年8月份，市发改委主任、党委书记等4个县处级领导职位空缺预告发布后，我市再次以空缺职位预告的方式推进干部人事制度改革。 \r\n<P>　　此次公开预告的6个岗位中有4个为市直单位正职、2个为县（市、区）委副书记。4个正职岗位分别市民政局局长、党组书记，市市级机关事务管理局局长、党组书记，市委党校常务副校长，市科协主席、党组书记。正职岗位推荐人选要求1960年1月1日以后出生，现任党政机关正县级领导职务、事业单位相当于正县级领导职务；党政机关副县级领导职务、事业单位相当于副县级领导职务，任职时间满2年，且任副县级领导职务2个岗位以上。县（市、区）委副书记人选要求1968年1月1日以后出生，现任党政机关副县级领导职务、事业单位相当于副县级领导职务，任职时间满2年。</P>\r\n<P>　　据了解，空缺职位预告鼓励干部个人积极自荐，同时接受群众推荐、领导干部推荐和单位党委（党组）推荐。对于每一空缺职位，各推荐主体原则上只能推荐提名一名人选。受理提名时间从11月11日至17日。根据《温州市县处级领导职位空缺预告提名工作试行办法》规定，提名受理结束后，将按照职位的资格条件对提名人选进行资格审查。审查合格者，根据其任职时间及经历、学习培训、年度考核、奖惩、基层工作经验等进行综合评价，按一定比例确定参考人选，提交市委全委会进行推荐提名，产生提名人选，提名人选经考察、沟通、征求意见，最后由市委常委会讨论决定任职人选。</P>', 'hsg', '2018-04-08 07:46:56', 'uploadfile/1340070002x47w.jpg', '3');
INSERT INTO `xinwentongzhi` VALUES ('224', '浙江省人民政府关于林建忠等任职的通知', '热门信息', '<TABLE height=600 cellSpacing=1 cellPadding=0 width=\"90%\" align=center border=0 valigh=\"top\">\r\n<TBODY>\r\n<TR>\r\n<TD style=\"FONT-SIZE: 12px; COLOR: #333333\" align=middle>浙政干〔2010〕38号</TD></TR>\r\n<TR>\r\n<TD id=fontzoom style=\"FONT-SIZE: 15px; COLOR: #333333; LINE-HEIGHT: 24px\" vAlign=top>\r\n<DIV id=printdiv name=\"printdiv\"><!--ZJEG_RSS.content.begin-->\r\n<P>鉴于中国计量学院行政领导班子换届，省政府研究决定，新一届行政领导班子由以下5人组成：<BR>林建忠任中国计量学院院长；<BR>蒋家新、冯时林、俞晓平、宋明顺任中国计量学院副院长。 \r\n<P>\r\n<P>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 二○一○年七月十六日 \r\n<P>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; （此件公开发布）</P><!--ZJEG_RSS.content.end--></DIV></TD></TR></TBODY></TABLE>', 'hsg', '2018-04-08 07:46:56', '', '1');
INSERT INTO `xinwentongzhi` VALUES ('225', '停电通知（9月13日?9月16日）', '热门信息', '<P>&nbsp;&nbsp;&nbsp; 因供电设备检修(如遇雨天延期），现安排下两周停电线路希各相关用户做好安排。</P>\r\n<P>星期二 9月13日 梧桥634线梁宅村、后?村等 7:00-19:00&nbsp; 新城504线 新桥村、仙坭船村、九刀连村、马路下村、北大洋村、金家沿村、倪后村、浦前村、水心村 7:00-19:00 江山531线 江山531线用户 8:00-17:00</P><!--advertisement code begin--><!--advertisement code end-->\r\n<P>星期三 9月14日 龙跃529线兴贤路、文卫路 7:00-19:00 繁荣581线 高岚866线 矾山镇八一路、高岚路、文昌路、新华街7:00-19:00</P>\r\n<P>星期四 9月15日 板桥486线云岩村等 7:00-19:00 风电3552线鹤顶山风电场 6:00-23:00</P>\r\n<P>星期五 9月16日 龙翔521线 前陈681线 龙翔路、江滨路、上厂街 7:00-19:00</P>', 'hsg', '2018-04-08 07:46:56', '', '1');
INSERT INTO `xinwentongzhi` VALUES ('226', '昆明（温州）苍南商会成立', '热门信息', '<TABLE cellSpacing=20 cellPadding=0 align=center>\r\n<TBODY>\r\n<TR align=middle>\r\n<TD><IMG src=\"http://pic2.66wz.com/0/10/32/22/10322249_955191.jpg\" border=0></TD></TR></TBODY></TABLE>\r\n<P><STRONG>名誉会长</STRONG></P><!--advertisement code begin--><!--advertisement code end-->\r\n<P>陈教敏　朱　彤　陈明存　陈培昆　董希怀　苏为佳　沈仁秀　陈舜彬</P>\r\n<P><STRONG>会长</STRONG></P>\r\n<P>刘华珍</P>\r\n<P><STRONG>常务副会长</STRONG></P>\r\n<P>陈教樟　王大馀　韩加智　陈相锦　陈庆领　阮进铭　林型德　朱　文　谢炳锦　陈金仓</P>\r\n<P><STRONG>副会长</STRONG></P>\r\n<P>杨德斌　陈德理　林守浪　林　逸　林敬腾　林衍勇　沈仁李　陈少甫　曾世通　易会欢</P>\r\n<P>张俊勤　柳圣共　杨庭建　陈教取　陈建明　高满?　陈志秋　许明安　潘仕程　林其万</P>\r\n<P>陈国允　张加岳　许祖汉 </P>\r\n<P><STRONG>秘书长</STRONG></P>\r\n<P>杨德斌（兼）</P>\r\n<P><STRONG>祝贺单位</STRONG></P>\r\n<P>云南省招商合作局　昆明市委统战部　昆明市工商业联合会　昆明市投资促进局</P>\r\n<P>官渡区人大常委会　官渡区公安局　温州市工商业联合会　中共苍南县委</P>\r\n<P>苍南县人大常委会　苍南县人民政府　苍南县政协　中共苍南县委统战部</P>\r\n<P>苍南县工商业联合会　苍南县新闻宣传中心　杭州市苍南商会　灵溪镇沪山办事处</P>\r\n<P>苍南人联谊总会　苍南人温州联络处　苍南人深圳联络处　苍南人泸山联络处</P>\r\n<P>云南省浙江商会　云南省温州商会　昆明温州总商会　云南省宁波商会</P>\r\n<P>昆明市工商联平阳商会　昆明市工商联瑞安商会　昆明市工商联龙湾商会</P>\r\n<P>昆明市工商联温岭商会　昆明市工商联永康商会　昆明市工商联台州商会</P>\r\n<P>昆明市工商联诸暨商会　昆明市工商联黄岩商会　昆明市工商联义乌商会</P>\r\n<P>昆明市工商联金华商会　昆明市安吉商会　昆明市工商联余杭商会</P>\r\n<P>昆明市工商联绍兴商会　宜良县浙江商会</P>', 'hsg', '2018-04-08 07:46:56', '', '1');
INSERT INTO `xinwentongzhi` VALUES ('227', '关于开展温州市第六次人口普查的公告（第一号）', '热门信息', '<P align=center><STRONG>温州市人民政府第六次人口普查领导小组办公室</STRONG></P>\r\n<P align=center><STRONG>关于开展温州市第六次人口普查的公告（第一号）</STRONG></P>\r\n<P>　　根据《国务院关于开展第六次全国人口普查的通知》（国发〔 2009〕23号）和《温州市人民政府关于在全市开展第六次人口普查的通知》（温政发〔 2009〕56号）精神，现将有关事项公告如下： </P>\r\n<P>　　<STRONG>一、普查对象</STRONG>：普查标准时点居住在我市辖区内的中国大陆公民、港澳台同胞和外国人（短期停留人员除外）以及不住在我市辖区内但户籍在温州的中国公民（已在境外定居的除外）。</P>\r\n<P>　　<STRONG>二、普查内容</STRONG>：姓名、性别、年龄、民族、国籍、受教育程度、行业、职业、迁移流动、社会保障、婚姻、生育、死亡、住房情况等。</P>\r\n<P>　　<STRONG>三、普查方式</STRONG>：采用全面调查的方法，以户为单位进行登记。按现住地登记的原则，每个人必须在现住地进行登记。普查对象不在户口登记地居住的，户口登记地要登记相应信息。</P>\r\n<P>　　<STRONG>四、普查时间</STRONG>：第六次全国人口普查的标准时点是2010年11月1日零时。普查工作分四个阶段进行，2010年10月底前为准备阶段，其中普查员入户清查摸底工作于9月至10月进行；11月1日-10日为入户正式登记阶段；2010年11月11日-2011年4月为复查、质量抽查、快速汇总、数据处理阶段；2011年4月-2012年底为数据发布、资料开发应用阶段。</P>\r\n<P>　　<STRONG>五、普查要求</STRONG>：依据《中华人民共和国统计法》和《全国人口普查条例》的规定，普查员入户调查时，应当佩戴县级以上人民政府普查机构统一颁发的普查员证件，任何冒充普查员的行为将被追究法律责任；人口普查对象应当真实、准确、完整、及时地提供人口普查所需的资料，阻碍普查机构和普查人员依法开展人口普查工作、构成违反治安管理行为的，由公安机关依法给予处罚；人口普查对象提供的资料，各级普查机构和普查人员将依法予以保密，不得作为对人口普查对象作出具体行政行为的依据，不得用于普查以外的目的。</P>\r\n<P>　　请社会各界及全体普查对象积极参与和配合人口普查工作，并欢迎对人口普查工作中的违法行为进行监督，举报电话：88967545、88983099。</P>\r\n<P>　　特此公告</P>\r\n<P align=right>　<STRONG>　二?一?年九月十日</STRONG></P>\r\n<META name=ContentEnd><!--ZJEG_RSS.content.end--><!--<$[信息内容]>end-->', 'hsg', '2018-04-08 07:46:56', '', '1');
INSERT INTO `xinwentongzhi` VALUES ('228', '关于拟命名第八批省级生态乡镇的公示', '热门信息', '<TABLE align=center>\r\n<TBODY>\r\n<TR>\r\n<TD><IMG style=\"WIDTH: 681px; HEIGHT: 370px\" height=369 src=\"http://www.wenzhou.gov.cn/picture/0/101125081355949.JPG\" width=791 border=0></TD></TR></TBODY></TABLE>', 'hsg', '2018-04-08 07:46:56', '', '6');
INSERT INTO `xinwentongzhi` VALUES ('229', '《钱库镇2010年党风廉政建设责任制考核方案》的通知', '热门信息', '各办事处、村（居）、部门单位：\r\n<div>\r\n	现将《钱库镇2010年党风廉政建设责任制考核方案》印发给你们，请结合实际，按规定要求制定本单位年度党风廉政建设责任制考核方案，并认真组织实施。\r\n</div>\r\n<div>\r\n</div>\r\n<div>\r\n</div>\r\n<div>\r\n</div>\r\n<div align=\"right\">\r\n	中共钱库镇委\r\n</div>\r\n<div align=\"right\">\r\n	钱库镇人民政府\r\n</div>\r\n<div align=\"right\">\r\n	2010年3月1日\r\n</div>', 'hsg', '2018-04-08 07:46:56', '', '3');
INSERT INTO `xinwentongzhi` VALUES ('230', '温州市政协向社会公开征集提案线索启事', '热门信息', '&nbsp;&nbsp;&nbsp; 政协提案是由政协委员和政协各参加单位向政协全体会议或常务委员会提出的，经审查立案后交付有关承办单位办理的书面意见和建议。为做好市政协九届五次会议的提案征集工作，拓宽反映社情民意渠道，帮助广大市政协委员和政协各参加单位更加广泛地了解人民群众对我市各方面工作的意见建议，从而使提案更加贴近社会、贴近群众、贴近实际，在推动我市“十二五”大发展、建设生态型、国际性、现代化大都市中发挥更大作用，市政协决定，从即日起至2010年11月30日止向社会公开征集提案线索。热忱欢迎社会各界通过网络和信函等形式，就我市经济社会发展以及人民群众关注的热点、难点等问题提出意见建议。征集到的线索由我们整理后，转交给市政协委员以及政协各参加单位，作为撰写提案时参考。线索提交方式：请登录市政府门户网站，网址：www.wenzhou.gov.cn,点击“提案线索”，填入相关内容报送即可。来信请寄温州市政协提案委办公室收，并在信封上注明：“提案线索”。 \r\n<P>　　在提供线索过程中应当注意以下几点：一是此次向社会公开征集的是提案的线索而不是提案，提案线索只有被具有提案资格的政协委员或政协参加单位采纳，并以提案形式递交、经过相关程序审查后才能成为政协提案。二是提案线索应符合提案有关条件才有可能被采纳。凡涉及党和国家秘密以及国家明令禁止的；已经进入民事、刑事、行政诉讼以及仲裁程序的；属于学术研讨的；指名举报的；宣传推介具体作品、产品的；以及其它方面不宜通过政协解决的问题等内容的不宜提出，也不予采纳。三是提供提案线索要实事求是，有理有据，最好有具体建议，并力求做到简明扼要。</P>\r\n<P align=right>　　温州市政协办公室</P>\r\n<P align=right>　　2010年11月5日</P></FOUNDER-CONTENT>\r\n<META name=ContentEnd><!--ZJEG_RSS.content.end--><!--<$[信息内容]>end-->', 'hsg', '2018-04-08 07:46:56', '', '8');
INSERT INTO `xinwentongzhi` VALUES ('236', 'grehehre', '图片分享', '<p align=\"center\">\r\n	<img alt=\"\" src=\"/kindeditor-4.1.10/php/../attached/image/20150412/20150412172552_44252.jpg\" />\r\n</p>\r\n<p align=\"center\">\r\n	<img alt=\"\" src=\"/kindeditor-4.1.10/php/../attached/image/20150412/20150412172552_98824.jpg\" />\r\n</p>\r\n<p align=\"center\">\r\n	<img alt=\"\" src=\"/kindeditor-4.1.10/php/../attached/image/20150412/20150412172553_43848.jpg\" />\r\n</p>', 'hsg', '2018-04-08 07:46:56', 'uploadfile/1428859570bz9b.jpg', '10');
INSERT INTO `xinwentongzhi` VALUES ('242', 'xxxx心情', '我的日志', 'xxxx心情xxxx心情xxxx心情xxxx心情xxxx心情xxxx心情', 'hsg', '2018-04-08 07:46:56', 'uploadfile/1520778676z2j0.jpg', '2');
INSERT INTO `xinwentongzhi` VALUES ('243', 'xxxxyyuj文章', '我的文章', 'xxxxyyuj文章xxxxyyuj文章xxxxyyuj文章xxxxyyuj文章xxxxyyuj文章xxxxyyuj文章', 'hsg', '2018-04-08 07:46:56', 'uploadfile/1520778711otid.jpg', '1');
INSERT INTO `xinwentongzhi` VALUES ('244', 'xxxx公告', '公告信息', 'xxxx公告xxxx公告xxxx公告xxxx公告xxxx公告xxxx公告', 'hsg', '2018-04-08 07:46:56', 'uploadfile/15207787435r9h.jpg', '2');
INSERT INTO `xinwentongzhi` VALUES ('249', '123', '我的日志', '123', 'hsg', '2018-04-09 03:50:50', '', '3');
INSERT INTO `xinwentongzhi` VALUES ('250', '3', '我的文章', '123', 'hsg', '2018-04-09 03:50:57', '', '2');
INSERT INTO `xinwentongzhi` VALUES ('251', '1', '公告信息', '1', 'hsg', '2018-04-09 03:51:04', '', '1');
INSERT INTO `xinwentongzhi` VALUES ('252', '13123', '图片分享', '<img src=\"/kindeditor-4.1.10/attached/image/20160419/20160419023836_66623.jpg\" width=\"179\" height=\"100\" alt=\"\" />13123123', 'hsg', '2018-04-09 03:51:33', '', '3');

-- ----------------------------
-- Table structure for `yonghuzhuce`
-- ----------------------------
DROP TABLE IF EXISTS `yonghuzhuce`;
CREATE TABLE `yonghuzhuce` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zhanghao` varchar(50) DEFAULT NULL,
  `mima` varchar(50) DEFAULT NULL,
  `xingming` varchar(50) DEFAULT NULL,
  `xingbie` varchar(50) DEFAULT NULL,
  `diqu` varchar(50) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `zhaopian` varchar(50) DEFAULT NULL,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `issh` varchar(10) DEFAULT '否',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of yonghuzhuce
-- ----------------------------
INSERT INTO `yonghuzhuce` VALUES ('26', '555', '555', '何升高', '男', '浙江', 'gsgs@163.com', 'uploadfile/13392103902z4y.jpg', '2018-04-08 07:46:56', '是');
INSERT INTO `yonghuzhuce` VALUES ('27', 'leejie', 'leejie', '李龙', '男', '湖北', 'fege@126.com', 'uploadfile/1339211863x4s3.jpg', '2018-04-08 07:46:56', '是');
INSERT INTO `yonghuzhuce` VALUES ('29', 'xwxxmx', 'xwxxmx', '吴江', '女', '北京', 'jrjtr@163.com', 'uploadfile/1339211786gts3.jpg', '2018-04-08 07:46:56', '否');
INSERT INTO `yonghuzhuce` VALUES ('33', 'ggee', 'ggee', 'ggee', '男', '浙江', 'wgww@163.com', 'uploadfile/14600487840gzr.jpg', '2018-04-08 07:46:56', '是');
INSERT INTO `yonghuzhuce` VALUES ('34', '999', '999', '小张', '男', '浙江', 'daf@ddkkd.com', 'uploadfile/14888095066gdk.jpg', '2018-04-08 07:46:56', '是');
INSERT INTO `yonghuzhuce` VALUES ('35', '888', '888', '李李', '男', '浙江', '666666@qq.com', 'uploadfile/15207786275w8v.jpg', '2018-04-08 07:46:56', '是');
INSERT INTO `yonghuzhuce` VALUES ('36', '1', '1', '1', '男', '浙江', '123123@qq.com', 'uploadfile/1523217026ndqh.jpg', '2018-04-09 03:50:28', '是');

-- ----------------------------
-- Table structure for `youqinglianjie`
-- ----------------------------
DROP TABLE IF EXISTS `youqinglianjie`;
CREATE TABLE `youqinglianjie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wangzhanmingcheng` varchar(50) DEFAULT NULL,
  `wangzhi` varchar(50) DEFAULT NULL,
  `addtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `logo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of youqinglianjie
-- ----------------------------
INSERT INTO `youqinglianjie` VALUES ('16', '百度', 'http://www.baidu.com', '2018-04-08 07:46:56', 'uploadfile/baidu.gif');
INSERT INTO `youqinglianjie` VALUES ('17', '谷歌', 'http://www.google.cn', '2018-04-08 07:46:56', 'uploadfile/google.png');
INSERT INTO `youqinglianjie` VALUES ('18', '新浪', 'http://www.sina.com', '2018-04-08 07:46:56', 'uploadfile/sina.gif');
INSERT INTO `youqinglianjie` VALUES ('19', 'QQ', 'http://www.qq.com', '2018-04-08 07:46:56', 'uploadfile/qq.jpg');
INSERT INTO `youqinglianjie` VALUES ('20', '网易', 'http://www.163.com', '2018-04-08 07:46:56', 'uploadfile/163.png');
