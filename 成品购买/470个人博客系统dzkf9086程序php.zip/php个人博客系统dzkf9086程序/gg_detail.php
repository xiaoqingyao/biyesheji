<?php
session_start();
include_once 'conn.php';
$id=$_GET["id"];
mysql_query("update xinwentongzhi set dianjilv=dianjilv+1 where id=$id");
?>
<html>
<head>
<title>���˲���ϵͳ</title>
<LINK href="qtimages/style.css" type=text/css rel=stylesheet>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<style type="text/css">
<!--
.STYLE1 {color: #D92B8A}
body {
	background-color: #0099CC;
}
.STYLE2 {
	color: #FFFFFF;
	font-weight: bold;
}
.STYLE7 {color: #993300; font-weight: bold; }
-->
</style>
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="1002" height="1203" border="0" align="center" cellpadding="0" cellspacing="0" id="__01">
	<tr>
		<td><?php include_once 'qttop.php';?></td>
	</tr>
	<tr>
		<td><table id="__01" width="1002" height="816" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td valign="top" background="qtimages/3.jpg"><?php include_once 'qtleft.php';?></td>
            <td valign="top" background="qtimages/2.jpg"><table id="__01" width="766" height="816" border="0" cellpadding="0" cellspacing="0">
              
              <tr>
                <td valign="top"><table id="__01" width="766" height="254" border="0" cellpadding="0" cellspacing="0">
                  <tr>
                    <td width="766" height="47" background="qtimages/1_02_02_01_01.jpg"><table width="100%" height="17" border="0" cellpadding="0" cellspacing="0">
                      <tr>
                        <td width="13%" height="17" align="right" valign="bottom"><span class="STYLE2"><strong>������ϸ</strong></span></td>
                        <td width="87%">&nbsp;</td>
                      </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td><table id="__01" width="766" height="197" border="0" cellpadding="0" cellspacing="0">
                        <tr>
                          <td width="11" background="qtimages/1_02_02_01_02_01.jpg">&nbsp;</td>
                          <td width="728" height="760" valign="top" bgcolor="#FFFFFF">
						  
						  
						  
						  <?php 
					$sql="select * from xinwentongzhi where id=".$id;
					$query=mysql_query($sql);
					 $rowscount=mysql_num_rows($query);
					  if($rowscount==0)
					  {}
					  else
					  {
					?>
                            <table width="97%" border="0" align="center" cellpadding="3" cellspacing="1" bordercolor="#B8D8E8" class="newsline" style="border-collapse:collapse">
                              <tr>
                                <td height="33" align="center"><span class="STYLE7"><?php echo mysql_result($query,0,"biaoti"); ?> (�����<?php echo mysql_result($query,0,"dianjilv"); ?>��)</span></td>
                              </tr>
                              <tr>
                                <td height="104" width="700"><?php echo mysql_result($query,0,"neirong");?></td>
                              </tr>
                              <tr>
                                <td align="right"><table width="100%" border="1" align="center" cellpadding="3" cellspacing="1" bordercolor="#119957" style="border-collapse:collapse">
                                  <tr>
                                    <td width="50" bgcolor="#D8E8F8">���</td>
                                    <td width="323" align="left" bgcolor='#D8E8F8'>��������</td>
                                    <td width="98" align="left" bgcolor='#D8E8F8'>������</td>
                                    <td width="106" align="center" bgcolor="#D8E8F8">����</td>
                                    <td width="106" align="center" bgcolor="#D8E8F8">����ʱ��</td>
                                  </tr>
                                  <?php 
    $sql="select * from pinglun where wenzhangID='$id' and biao='xinwentongzhi'";
  
  $sql=$sql." order by id desc";
  
$query=mysql_query($sql);
  $rowscount=mysql_num_rows($query);
  if($rowscount==0)
  {}
  else
  {
  $pagelarge=10;//ÿҳ������
  $pagecurrent=$_GET["pagecurrent"];
  if($rowscount%$pagelarge==0)
  {
		$pagecount=$rowscount/$pagelarge;
  }
  else
  {
   		$pagecount=intval($rowscount/$pagelarge)+1;
  }
  if($pagecurrent=="" || $pagecurrent<=0)
{
	$pagecurrent=1;
}
 
if($pagecurrent>$pagecount)
{
	$pagecurrent=$pagecount;
}
		$ddddd=$pagecurrent*$pagelarge;
	if($pagecurrent==$pagecount)
	{
		if($rowscount%$pagelarge==0)
		{
		$ddddd=$pagecurrent*$pagelarge;
		}
		else
		{
		$ddddd=$pagecurrent*$pagelarge-$pagelarge+$rowscount%$pagelarge;
		}
	}

	for($i=$pagecurrent*$pagelarge-$pagelarge;$i<$ddddd;$i++)
{
  ?>
                                  <tr>
                                    <td width="50"><?php
	echo $i+1;
?></td>
                                    <td align="left"><?php echo mysql_result($query,$i,pinglunneirong);?></td>
                                    <td align="left"><?php echo mysql_result($query,$i,pinglunren);?></td>
                                    <td width="106" align="center"><?php
echo mysql_result($query,$i,"pingfen");
?></td>
                                    <td width="106" align="center"><?php
echo mysql_result($query,$i,"addtime");
?></td>
                                  </tr>
                                  <?php
	}
}
?>
                                </table></td>
                              </tr>
                              <tr>
                                <td align="right"><a  onClick="javascript:history.back();" style="cursor:pointer">����</a> <a href="pinglunadd.php?id=<?php echo $id ?>&biao=xinwentongzhi" >����</a></td>
                              </tr>
                            </table>
                            <?php
					}
					?>
                           
						   
						   
						   </td>
                          <td width="27" background="qtimages/1_02_02_01_02_03.jpg">&nbsp;</td>
                        </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td><img src="qtimages/1_02_02_01_03.jpg" width="766" height="10" alt=""></td>
                  </tr>
                </table></td>
              </tr>
              
            </table></td>
          </tr>
        </table></td>
	</tr>
	<tr>
		<td><?php include_once 'qtdown.php';?></td>
	</tr>
</table>
</body>
</html>