<?php
session_start();
include_once 'conn.php';
$ndate =date("Y-m-d");
$addnew=$_POST["addnew"];
if ($addnew=="1" )
{
	$zhanghao=$_POST["zhanghao"];    $xingming=$_POST["xingming"];    $xingbie=$_POST["xingbie"];    $fenzu=$_POST["fenzu"];    $tianjiaren=$_POST["tianjiaren"];    $beizhu=$_POST["beizhu"];    
	//ischongfu("select id from haoyouxinxi where tianjiaren='".$tianjiaren."'");
	$sql="insert into haoyouxinxi(zhanghao,xingming,xingbie,fenzu,tianjiaren,beizhu) values('$zhanghao','$xingming','$xingbie','$fenzu','$tianjiaren','$beizhu') ";
	mysql_query($sql);
	echo "<script>javascript:alert('���ӳɹ�!');location.href='haoyouxinxi_add.php';</script>";
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>�ޱ����ĵ�</title><script language="javascript" src="js/hsgrili.js"></script><link rel="stylesheet" href="css.css" type="text/css">
</head>
<script language="javascript">
	
	
	function OpenScript(url,width,height)
{
  var win = window.open(url,"SelectToSort",'width=' + width + ',height=' + height + ',resizable=1,scrollbars=yes,menubar=no,status=yes' );
}
	function OpenDialog(sURL, iWidth, iHeight)
{
   var oDialog = window.open(sURL, "_EditorDialog", "width=" + iWidth.toString() + ",height=" + iHeight.toString() + ",resizable=no,left=0,top=0,scrollbars=no,status=no,titlebar=no,toolbar=no,menubar=no,location=no");
   oDialog.focus();
}
</script>
<body>
<p>���Ӻ�����Ϣ�� ��ǰ���ڣ� <?php echo $ndate; ?></p>
<script language="javascript">
	function check()
{
	if(document.form1.zhanghao.value==""){alert("�������˺�");document.form1.zhanghao.focus();return false;}    if(document.form1.xingming.value==""){alert("����������");document.form1.xingming.focus();return false;}    
}
	function gow()
	{
		location.href='peixunccccailiao_add.php?jihuabifffanhao='+document.form1.jihuabifffanhao.value;
	}
</script>
 <?php
 $sql="select * from yonghuzhuce where id=".$_GET["id"];
 $query=mysql_query($sql);
 $rowscount=mysql_num_rows($query);
 if($rowscount>0)
 {
 	$zhanghao=mysql_result($query,0,zhanghao);$xingming=mysql_result($query,0,xingming);$xingbie=mysql_result($query,0,xingbie);
 }
?>
<form id="form1" name="form1" method="post" action="">
<table width="100%" border="1" align="center" cellpadding="3" cellspacing="1" bordercolor="#00FFFF" style="border-collapse:collapse">    
	<tr><td>�˺ţ�</td><td><input name='zhanghao' type='text' id='zhanghao' value='' style='border:solid 1px #000000; color:#666666' />&nbsp;*</td></tr><script language="javascript">document.form1.zhanghao.value='<?php echo $zhanghao?>';</script>    <tr><td>������</td><td><input name='xingming' type='text' id='xingming' value='' style='border:solid 1px #000000; color:#666666' />&nbsp;*</td></tr><script language="javascript">document.form1.xingming.value='<?php echo $xingming?>';</script>    <tr><td>�Ա�</td><td><input name='xingbie' type='text' id='xingbie' value='' style='border:solid 1px #000000; color:#666666' /></td></tr><script language="javascript">document.form1.xingbie.value='<?php echo $xingbie?>';</script>    <tr><td>���飺</td><td><select name='fenzu' id='fenzu' style='border:solid 1px #000000; color:#666666'></select></td></tr>    <tr><td>�����ˣ�</td><td><input name='tianjiaren' type='text' id='tianjiaren' value='<?php echo $_SESSION['username'];?>' style='border:solid 1px #000000; color:#666666' /></td></tr>    <tr><td>��ע��</td><td><textarea name='beizhu' cols='50' rows='8' id='beizhu' style='border:solid 1px #000000; color:#666666'></textarea></td></tr>    

    <tr>
      <td>&nbsp;</td>
      <td><input type="hidden" name="addnew" value="1" />
        <input type="submit" name="Submit" value="����" onclick="return check();"  style='border:solid 1px #000000; color:#666666' />
      <input type="reset" name="Submit2" value="����" style='border:solid 1px #000000; color:#666666' /></td>
    </tr>
  </table>
</form>
<p>&nbsp;</p>
<?php
	function ischongfu($sql)
	{
		$query=mysql_query($sql);
 		$rowscount=mysql_num_rows($query);
		if($rowscount>0)
		{
			echo "<script>javascript:alert('�Բ��𣬸��������Ѿ����ڣ��뻻����������!');history.back();</script>";
			exit;
		}
		
	}
?>
</body>
</html>

