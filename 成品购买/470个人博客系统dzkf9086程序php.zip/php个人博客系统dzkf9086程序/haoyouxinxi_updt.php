<?php 
session_start();
include_once 'conn.php';
$id=$_GET["id"];
$ndate =date("Y-m-d");
$addnew=$_POST["addnew"];
if ($addnew=="1" )
{

	$zhanghao=$_POST["zhanghao"];
    $xingming=$_POST["xingming"];
    $xingbie=$_POST["xingbie"];
    $fenzu=$_POST["fenzu"];
    $tianjiaren=$_POST["tianjiaren"];
    $beizhu=$_POST["beizhu"];
    
	$sql="update haoyouxinxi set zhanghao='$zhanghao',xingming='$xingming',xingbie='$xingbie',fenzu='$fenzu',tianjiaren='$tianjiaren',beizhu='$beizhu' where id= ".$id;
	mysql_query($sql);
	echo "<script>javascript:alert('�޸ĳɹ�!');location.href='haoyouxinxi_list.php';</script>";
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>�޸ĺ�����Ϣ</title><link rel="stylesheet" href="css.css" type="text/css"><script language="javascript" src="js/hsgrili.js"></script>
</head>
<script language="javascript">
	
	
	function OpenScript(url,width,height)
{
  var win = window.open(url,"SelectToSort",'width=' + width + ',height=' + height + ',resizable=1,scrollbars=yes,menubar=no,status=yes' );
}
	function OpenDialog(sURL, iWidth, iHeight)
{
   var oDialog = window.open(sURL, "_EditorDialog", "width=" + iWidth.toString() + ",height=" + iHeight.toString() + ",resizable=no,left=0,top=0,scrollbars=no,status=no,titlebar=no,toolbar=no,menubar=no,location=no");
   oDialog.focus();
}
</script>
<body>
<p>�޸ĺ�����Ϣ�� ��ǰ���ڣ� <?php echo $ndate; ?></p>
<?php
$sql="select * from haoyouxinxi where id=".$id;
$query=mysql_query($sql);
$rowscount=mysql_num_rows($query);
if($rowscount>0)
{
?>
<form id="form1" name="form1" method="post" action="">
<table width="100%" border="1" align="center" cellpadding="3" cellspacing="1" bordercolor="#00FFFF" style="border-collapse:collapse"> 

      <tr><td>�˺ţ�</td><td><input name='zhanghao' type='text' id='zhanghao' value='<?php echo mysql_result($query,$i,zhanghao);?>' /></td></tr>
    <tr><td>������</td><td><input name='xingming' type='text' id='xingming' value='<?php echo mysql_result($query,$i,xingming);?>' /></td></tr>
    <tr><td>�Ա�</td><td><input name='xingbie' type='text' id='xingbie' value='<?php echo mysql_result($query,$i,xingbie);?>' /></td></tr>
    <tr><td>���飺</td><td><select name='fenzu' id='fenzu'>
      <option value="��ѧͬѧ">��ѧͬѧ</option>
      <option value="����ͬѧ">����ͬѧ</option>
      <option value="����ͬѧ">����ͬѧ</option>
      <option value="����">����</option>
      <option value="ͬ��">ͬ��</option>
      <option value="�ر����">�ر����</option>
      <option value="��ͨ����">��ͨ����</option>
      <option value="İ·">İ·</option>
    </select></td></tr><script language="javascript">document.form1.fenzu.value='<?php echo mysql_result($query,$i,fenzu);?>';</script>
    <tr><td>�����ˣ�</td><td><input name='tianjiaren' type='text' id='tianjiaren' value='<?php echo mysql_result($query,$i,tianjiaren);?>' /></td></tr>
    <tr><td>��ע��</td><td><textarea name='beizhu' cols='50' rows='8' id='beizhu'><?php echo mysql_result($query,$i,beizhu);?></textarea></td></tr>
    
   
   
    <tr>
      <td>&nbsp;</td>
      <td><input name="addnew" type="hidden" id="addnew" value="1" />
      <input type="submit" name="Submit" value="�޸�" style='border:solid 1px #000000; color:#666666' />
      <input type="reset" name="Submit2" value="����" style='border:solid 1px #000000; color:#666666' /></td>
    </tr>
  </table>
</form>
<?php
	}
?>
<p>&nbsp;</p>
</body>
</html>

