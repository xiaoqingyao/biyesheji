<?php
include_once 'conn.php';
session_start();
 if($_SESSION["username"]=="")
 {
	echo "<script>javascript:alert('�Բ��������ȵ�½��');location.href='index.php';</script>";
	exit;
 }
$addnew=$_POST["addnew"];
if ($addnew=="1" )
{
	
	$zhanghao=$_POST["zhanghao"];$zhaopian=$_POST["biaoqing"];$xingming=$_POST["xingming"];$liuyan=$_POST["liuyan"];
	$sql="insert into liuyanban(zhanghao,zhaopian,xingming,liuyan) values('$zhanghao','$zhaopian','$xingming','$liuyan') ";
	mysql_query($sql);
	echo "<script>javascript:alert('���Գɹ�!');location.href='lyblist.php';</script>";
}
?>
<html>
<head>
<title>���˲���ϵͳ</title><LINK href="qtimages/style.css" type=text/css rel=stylesheet>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<style type="text/css">
<!--
body {
	background-color: #0099CC;
}
.STYLE2 {
	color: #FFFFFF;
	font-weight: bold;
}
.STYLE3 {color: #000000}
-->
</style>
</head>
<script language="javascript">
	function check()
{
	if(document.form1.zhanghao.value==""){alert("�������˺�");document.form1.zhanghao.focus();return false;}if(document.form1.xingming.value==""){alert("����������");document.form1.xingming.focus();return false;}if(document.form1.liuyan.value==""){alert("����������");document.form1.liuyan.focus();return false;}
}

</script>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="1002" height="1203" border="0" align="center" cellpadding="0" cellspacing="0" id="__01">
	<tr>
		<td><?php include_once 'qttop.php';?></td>
	</tr>
	<tr>
		<td><table id="__01" width="1002" height="816" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td valign="top" background="qtimages/3.jpg"><?php include_once 'qtleft.php';?></td>
            <td valign="top" background="qtimages/2.jpg"><table id="__01" width="766" height="816" border="0" cellpadding="0" cellspacing="0">
              
              <tr>
                <td valign="top"><table id="__01" width="766" height="254" border="0" cellpadding="0" cellspacing="0">
                  <tr>
                    <td width="766" height="47" background="qtimages/1_02_02_01_01.jpg"><table width="100%" height="17" border="0" cellpadding="0" cellspacing="0">
                      <tr>
                        <td width="13%" height="17" align="right" valign="bottom"><span class="STYLE2"><strong>��������</strong></span></td>
                        <td width="72%">&nbsp;</td>
                        <td width="15%"><a href="lyblist.php"><strong><font class="STYLE3">�鿴��������</font></strong></a></td>
                      </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td><table id="__01" width="766" height="197" border="0" cellpadding="0" cellspacing="0">
                        <tr>
                          <td width="11" background="qtimages/1_02_02_01_02_01.jpg">&nbsp;</td>
                          <td width="728" height="760" valign="top" bgcolor="#FFFFFF"><table width="96%" border="1" align="left" cellpadding="3" cellspacing="1" bordercolor="#B8D8E8" style="border-collapse:collapse">
                            <form name="form1" method="post" action="">
                              <tr>
                                <td>�˺ţ�</td>
                                <td><input name='zhanghao' type='text' id='zhanghao' value='<?php echo $_SESSION["username"];?>' />
                                  &nbsp;*</td>
                              </tr>
                              <tr>
                                <td>ͷ��</td>
                                <td><input name="biaoqing" type="radio" value="1" checked="checked" />
                                  <img src="img/1.gif" width="64" height="71" />
                                  <input type="radio" name="biaoqing" value="2" />
                                  <img src="img/2.gif" width="64" height="71" />
                                  <input type="radio" name="biaoqing" value="3" />
                                  <img src="img/3.gif" width="64" height="71" />
                                  <input type="radio" name="biaoqing" value="4" />
                                  <img src="img/4.gif" width="64" height="71" />
                                  <input type="radio" name="biaoqing" value="5" />
                                  <img src="img/5.gif" width="64" height="71" /></td>
                              </tr>
                              <tr>
                                <td>������</td>
                                <td><input name='xingming' type='text' id='xingming' value='<?php echo $_SESSION["xm"];?>' />
                                  &nbsp;*</td>
                              </tr>
                              <tr>
                                <td>���ԣ�</td>
                                <td><textarea name='liuyan' cols='50' rows='8' id='liuyan'></textarea>
                                  &nbsp;*</td>
                              </tr>
                              <tr>
                                <td>&nbsp;</td>
                                <td><input type="hidden" name="addnew" value="1" />
                                    <input type="submit" name="Submit" value="����" onClick="return check();" />
                                    <input type="reset" name="Submit2" value="����" /></td>
                              </tr>
                            </form>
                          </table>
                            <p align="center">&nbsp;</p>
                            <p align="center"></p>
                            <p align="center">&nbsp;</p></td>
                          <td width="27" background="qtimages/1_02_02_01_02_03.jpg">&nbsp;</td>
                        </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td><img src="qtimages/1_02_02_01_03.jpg" width="766" height="10" alt=""></td>
                  </tr>
                </table></td>
              </tr>
              
            </table></td>
          </tr>
        </table></td>
	</tr>
	<tr>
		<td><?php include_once 'qtdown.php';?></td>
	</tr>
</table>
</body>
</html>