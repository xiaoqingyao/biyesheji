<?php 
include_once 'conn.php';
$ndate =date("Y-m-d");
$addnew=$_POST["addnew"];
if ($addnew=="1" )
{
	
	$wenzhangID=$_POST["wenzhangID"];$pinglunneirong=$_POST["pinglunneirong"];$pinglunren=$_POST["pinglunren"];
	$sql="insert into pinglun(wenzhangID,pinglunneirong,pinglunren) values('$wenzhangID','$pinglunneirong','$pinglunren') ";
	mysql_query($sql);
	echo "<script>javascript:alert('���ӳɹ�!');location.href='pinglun_add.php';</script>";
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>����</title><script language="javascript" src="js/Calendar.js"></script><link rel="stylesheet" href="css.css" type="text/css">
</head>
<script language="javascript">
	
	
	function OpenScript(url,width,height)
{
  var win = window.open(url,"SelectToSort",'width=' + width + ',height=' + height + ',resizable=1,scrollbars=yes,menubar=no,status=yes' );
}
	function OpenDialog(sURL, iWidth, iHeight)
{
   var oDialog = window.open(sURL, "_EditorDialog", "width=" + iWidth.toString() + ",height=" + iHeight.toString() + ",resizable=no,left=0,top=0,scrollbars=no,status=no,titlebar=no,toolbar=no,menubar=no,location=no");
   oDialog.focus();
}
</script>
<body>
<p>�������ԣ� ��ǰ���ڣ� <?php echo $ndate; ?></p>
<script language="javascript">
	function check()
{
	if(document.form1.wenzhangID.value==""){alert("����������ID");document.form1.wenzhangID.focus();return false;}if(document.form1.pinglunneirong.value==""){alert("��������������");document.form1.pinglunneirong.focus();return false;}
}
	function gow()
	{
		location.href='peixunccccailiao_add.php?jihuabifffanhao='+document.form1.jihuabifffanhao.value;
	}
</script>
<form id="form1" name="form1" method="post" action="">
<table width="100%" border="1" align="center" cellpadding="3" cellspacing="1" bordercolor="#00FFFF" style="border-collapse:collapse">    
	<tr><td>����ID��</td><td><input name='wenzhangID' type='text' id='wenzhangID' value='' />&nbsp;*</td></tr><tr><td>�������ݣ�</td><td><textarea name='pinglunneirong' cols='50' rows='8' id='pinglunneirong'></textarea>&nbsp;*</td></tr><tr><td>�����ˣ�</td><td><input name='pinglunren' type='text' id='pinglunren' value='' /></td></tr>

    <tr>
      <td>&nbsp;</td>
      <td><input type="hidden" name="addnew" value="1" />
        <input type="submit" name="Submit" value="����" onclick="return check();" />
      <input type="reset" name="Submit2" value="����" /></td>
    </tr>
  </table>
</form>
<p>&nbsp;</p>
</body>
</html>

