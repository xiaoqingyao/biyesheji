<?php 
$id=$_GET["id"];
include_once 'conn.php';
$ndate =date("Y-m-d");
$addnew=$_POST["addnew"];
if ($addnew=="1" )
{

	$wenzhangID=$_POST["wenzhangID"];$pinglunneirong=$_POST["pinglunneirong"];$pinglunren=$_POST["pinglunren"];
	$sql="update pinglun set wenzhangID='$wenzhangID',pinglunneirong='$pinglunneirong',pinglunren='$pinglunren' where id= ".$id;
	mysql_query($sql);
	echo "<script>javascript:alert('�޸ĳɹ�!');location.href='pinglun_list.php';</script>";
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>�޸�����</title><link rel="stylesheet" href="css.css" type="text/css"><script language="javascript" src="js/Calendar.js"></script>
</head>
<script language="javascript">
	
	
	function OpenScript(url,width,height)
{
  var win = window.open(url,"SelectToSort",'width=' + width + ',height=' + height + ',resizable=1,scrollbars=yes,menubar=no,status=yes' );
}
	function OpenDialog(sURL, iWidth, iHeight)
{
   var oDialog = window.open(sURL, "_EditorDialog", "width=" + iWidth.toString() + ",height=" + iHeight.toString() + ",resizable=no,left=0,top=0,scrollbars=no,status=no,titlebar=no,toolbar=no,menubar=no,location=no");
   oDialog.focus();
}
</script>
<body>
<p>�޸����ۣ� ��ǰ���ڣ� <?php echo $ndate; ?></p>
<?php
$sql="select * from pinglun where id=".$id;
$query=mysql_query($sql);
$rowscount=mysql_num_rows($query);
if($rowscount>0)
{
?>
<form id="form1" name="form1" method="post" action="">
<table width="100%" border="1" align="center" cellpadding="3" cellspacing="1" bordercolor="#00FFFF" style="border-collapse:collapse"> 

      <tr><td>����ID��</td><td><input name='wenzhangID' type='text' id='wenzhangID' value='<?php echo mysql_result($query,$i,wenzhangID);?>' /></td></tr><tr><td>�������ݣ�</td><td><textarea name='pinglunneirong' cols='50' rows='8' id='pinglunneirong'><?php echo mysql_result($query,$i,pinglunneirong);?></textarea></td></tr><tr><td>�����ˣ�</td><td><input name='pinglunren' type='text' id='pinglunren' value='<?php echo mysql_result($query,$i,pinglunren);?>' /></td></tr>
   
   
    <tr>
      <td>&nbsp;</td>
      <td><input name="addnew" type="hidden" id="addnew" value="1" />
      <input type="submit" name="Submit" value="�޸�" />
      <input type="reset" name="Submit2" value="����" /></td>
    </tr>
  </table>
</form>
<?php
	}
?>
<p>&nbsp;</p>
</body>
</html>

