<?php
session_start();
if($_SESSION["username"]=="")
{
	echo "<script>javascript:alert('�Բ��������ȵ�½��');location.href='index.php';</script>";
	exit;
}
include_once 'conn.php';
$id=$_GET["id"];
$addnew=$_POST["addnew"];

if ($addnew=="1" )
{
	
	$wenzhangID=$_POST["wenzhangID"];$pinglunneirong=$_POST["pinglunneirong"];$pinglunren=$_POST["pinglunren"];$biao=$_POST["biao"];$pingfen=$_POST["pingfen"];
	$sql="insert into pinglun(wenzhangID,pinglunneirong,pinglunren,biao,pingfen) values('$wenzhangID','$pinglunneirong','$pinglunren','$biao','$pingfen') ";
	mysql_query($sql);
	
	echo "<script>javascript:alert('�����ɹ�!');location.href='index.php';</script>";
}
?>
<html>
<head>
<title>���˲���ϵͳ</title>
<LINK href="qtimages/style.css" type=text/css rel=stylesheet>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<style type="text/css">
<!--
.STYLE1 {color: #D92B8A}
body {
	background-color: #0099CC;
}
.STYLE2 {
	color: #FFFFFF;
	font-weight: bold;
}
.STYLE7 {color: #993300; font-weight: bold; }
-->
</style>
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="1002" height="1203" border="0" align="center" cellpadding="0" cellspacing="0" id="__01">
	<tr>
		<td><?php include_once 'qttop.php';?></td>
	</tr>
	<tr>
		<td><table id="__01" width="1002" height="816" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td valign="top" background="qtimages/3.jpg"><?php include_once 'qtleft.php';?></td>
            <td valign="top" background="qtimages/2.jpg"><table id="__01" width="766" height="816" border="0" cellpadding="0" cellspacing="0">
              
              <tr>
                <td valign="top"><table id="__01" width="766" height="254" border="0" cellpadding="0" cellspacing="0">
                  <tr>
                    <td width="766" height="47" background="qtimages/1_02_02_01_01.jpg"><table width="100%" height="17" border="0" cellpadding="0" cellspacing="0">
                      <tr>
                        <td width="13%" height="17" align="right" valign="bottom"><span class="STYLE2"><strong>��������</strong></span></td>
                        <td width="87%">&nbsp;</td>
                      </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td><table id="__01" width="766" height="197" border="0" cellpadding="0" cellspacing="0">
                        <tr>
                          <td width="11" background="qtimages/1_02_02_01_02_01.jpg">&nbsp;</td>
                          <td width="728" height="760" valign="top" bgcolor="#FFFFFF"><table width="100%" border="1" align="center" cellpadding="3" cellspacing="1" bordercolor="#00FFFF" style="border-collapse:collapse">
                            <form name="form1" method="post" action="">
                              <tr style="display:none">
                                <td>����ID��</td>
                                <td><input name='wenzhangID' type='text' id='wenzhangID' value='<?php echo $_GET["id"];?>' />
                                  &nbsp;*
                                  <input name="biao" type="hidden" id="biao" value="<?php echo $_GET["biao"];?>"></td>
                              </tr>
                              <tr style="display:none">
                                <td>���֣�</td>
                                <td><select name="pingfen" id="pingfen">
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                  </select>
                                </td>
                              </tr>
                              <tr>
                                <td>�������ݣ�</td>
                                <td><textarea name='pinglunneirong' cols='50' rows='8' id='pinglunneirong'></textarea>
                                  &nbsp;*</td>
                              </tr>
                              <tr>
                                <td>�����ˣ�</td>
                                <td><input name='pinglunren' type='text' id='pinglunren' value='<?php echo $_SESSION["username"];?>' /></td>
                              </tr>
                              <tr>
                                <td>&nbsp;</td>
                                <td><input type="hidden" name="addnew" value="1" />
                                    <input type="submit" name="Submit" value="����" onClick="return check();" />
                                    <input type="reset" name="Submit2" value="����" /></td>
                              </tr>
                            </form>
                          </table></td>
                          <td width="27" background="qtimages/1_02_02_01_02_03.jpg">&nbsp;</td>
                        </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td><img src="qtimages/1_02_02_01_03.jpg" width="766" height="10" alt=""></td>
                  </tr>
                </table></td>
              </tr>
              
            </table></td>
          </tr>
        </table></td>
	</tr>
	<tr>
		<td><?php include_once 'qtdown.php';?></td>
	</tr>
</table>
</body>
</html>