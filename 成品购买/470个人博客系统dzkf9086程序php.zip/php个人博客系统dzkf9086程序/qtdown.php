
		
		<table id="__01" width="1002" height="97" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td><img src="qtimages/1_03_01.jpg" width="1002" height="23" alt=""></td>
          </tr>
          <tr>
            <td width="1002" height="74" background="qtimages/1_03_02.jpg"><table width="83%" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                <td align="center" class="STYLE2">&nbsp;</td>
              </tr>
              <tr>
                <td height="30" align="center" class="STYLE2">��Ȩ���У����˲���ϵͳ </td>
              </tr>
              <tr>
                <td height="28" align="center" class="STYLE2">&nbsp;</td>
              </tr>
            </table></td>
          </tr>
</table>