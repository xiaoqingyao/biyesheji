<script language="javascript">
function checklog()
{
	if(document.userlog.username.value=="" || document.userlog.pwd1.value=="" || document.userlog.yzm.value=="")
	{
		alert("����������");
		return false;
	}
}
</script>
<table id="__01" width="236" border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td><table id="__01" width="236" height="211" border="0" cellpadding="0" cellspacing="0">
                  <tr>
                    <td width="236" height="50" background="qtimages/1_02_01_01_01.jpg"><table width="100%" height="20" border="0" cellpadding="0" cellspacing="0">
                      <tr>
                        <td width="48%" height="20" align="right"><span class="STYLE2">�����Ƽ�</span></td>
                        <td width="52%">&nbsp;</td>
                      </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td><table id="__01" width="236" height="147" border="0" cellpadding="0" cellspacing="0">
                      <tr>
                        <td><img src="qtimages/1_02_01_01_02_01.jpg" width="24" height="147" alt=""></td>
                        <td width="200" height="147" background="qtimages/1_02_01_01_02_02.jpg"><marquee border="0" direction="up" height="100%" onMouseOut="start()" onMouseOver="stop()"
                scrollamount="1" scrolldelay="50">
                          <TABLE width="100%" height="100%" >
                      <TR><TD ><table width="99%" border="0" align="center" cellpadding="0" cellspacing="0" class="newsline">
                        <?php 
    $sql="select * from xinwentongzhi where leibie='�ҵ�����'";
  
  $sql=$sql." order by id desc limit 0,5";
  
$query=mysql_query($sql);
  $rowscount=mysql_num_rows($query);
  if($rowscount==0)
  {}
  else
  {

	for($i=0;$i<$rowscount;$i++)
{
  ?>
                        <tr height="25">
                          <td width="11%" align="left" class="newsline"><img src="qtimages/1.jpg" /></td>
                          <td width="89%" class="newsline"><a href="gg_detail.php?id=<?php echo mysql_result($query,$i,"id");?>"><?php 
						  if (strlen(mysql_result($query,$i,"biaoti"))>24)
								{
									echo substr(mysql_result($query,$i,"biaoti"),0,24);
								}
								else
								{
									echo mysql_result($query,$i,"biaoti");
								}
						  ?></a></td>
                          </tr>
                        <?php
						}
					  }
					  ?>
                      </table></TD></TR></TABLE></marquee></td>
                        <td><img src="qtimages/1_02_01_01_02_03.jpg" width="12" height="147" alt=""></td>
                      </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td><img src="qtimages/1_02_01_01_03.jpg" width="236" height="14" alt=""></td>
                  </tr>
                </table></td>
              </tr>
              
              <tr>
                <td><table id="__01" width="236" height="213" border="0" cellpadding="0" cellspacing="0">
                  <tr>
                    <td width="236" height="52" background="qtimages/1_02_01_03_01.jpg"><table width="100%" height="20" border="0" cellpadding="0" cellspacing="0">
                      <tr>
                        <td width="48%" height="20" align="right"><span class="STYLE2">վ������</span></td>
                        <td width="52%">&nbsp;</td>
                      </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td><table id="__01" width="236" height="145" border="0" cellpadding="0" cellspacing="0">
                      <tr>
                        <td><img src="qtimages/1_02_01_03_02_01.jpg" width="24" height="145" alt=""></td>
                        <td width="200" height="145" background="qtimages/1_02_01_01_02_02.jpg"><table width="93%" height="100" border="0" align="center" cellpadding="0" cellspacing="0">
                          <form action="news.php" method="post" name="formsearch" id="formsearch">
                            <tr>
                              <td width="19%">����</td>
                              <td width="81%"><input name="biaoti" type="text" id="biaoti" size="20" style="width:130px; height:24px; border:solid 1px #000000; color:#666666" /></td>
                            </tr>
                            <tr>
                              <td>���</td>
                              <td><select name="lb" style="width:130px; height:24px; border:solid 1px #000000; color:#666666">
                                  <?php
								  $sql="select distinct(leibie) from xinwentongzhi";
								  $query=mysql_query($sql);
								$rowscount=mysql_num_rows($query);
								if($rowscount>0)
								{
								for($i=0;$i<$rowscount;$i++)
	 							{
								  ?>
								  <option value="<?php echo mysql_result($query,$i,"leibie")?>"><?php echo mysql_result($query,$i,"leibie")?></option>
								  <?php
								  }
								  }
								  ?>
                                </select>                              </td>
                            </tr>
                            <tr>
                              <td>&nbsp;</td>
                              <td><input type="submit" name="Submit4" value="�ύ" style=" height:19px; border:solid 1px #000000; color:#666666" /></td>
                            </tr>
                          </form>
                        </table></td>
                        <td><img src="qtimages/1_02_01_03_02_03.jpg" width="12" height="145" alt=""></td>
                      </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td><img src="qtimages/1_02_01_03_03.jpg" width="236" height="16" alt=""></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td><table id="__01" width="236" height="195" border="0" cellpadding="0" cellspacing="0">
                  <tr>
                    <td width="236" height="50" background="qtimages/1_02_01_04_01.jpg"><table width="100%" height="20" border="0" cellpadding="0" cellspacing="0">
                      <tr>
                        <td width="48%" height="20" align="right"><span class="STYLE2">��������</span></td>
                        <td width="52%">&nbsp;</td>
                      </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td><table id="__01" width="236" height="131" border="0" cellpadding="0" cellspacing="0">
                      <tr>
                        <td><img src="qtimages/1_02_01_04_02_01.jpg" width="24" height="131" alt=""></td>
                        <td width="198" height="131" background="qtimages/1_02_01_01_02_02.jpg"><table class="newsline" cellspacing="0" cellpadding="0" width="100%" 
                  align="center" border="0">
                          <tbody>
                            <?php 
					  $sql="select * from youqinglianjie order by id desc";
					  $query=mysql_query($sql);
					  $rowscount=mysql_num_rows($query);
					  if($rowscount>0)
					  {
					  	for($i=0;$i<$rowscount;$i++)
						{
						?>
                            <tr>
                              <td width="12%" height="25" align="center"><span class="STYLE2"><img src="qtimages/1.jpg" /></span></td>
                              <td width="20%" height="25"><a href="<?php echo mysql_result($query,$i,"wangzhi");?>" target="_blank" ><?php echo mysql_result($query,$i,"wangzhanmingcheng");?></a></td>
                              <td width="68%" height="25"><a href="<?php echo mysql_result($query,$i,"wangzhi");?>" target="_blank" ><?php echo mysql_result($query,$i,"wangzhi");?></a></td>
                            </tr>
                            <?php
						}
					  }
					  ?>
                          </tbody>
                        </table></td>
                        <td><img src="qtimages/1_02_01_04_02_03.jpg" width="14" height="131" alt=""></td>
                      </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td><img src="qtimages/1_02_01_04_03.jpg" width="236" height="14" alt=""></td>
                  </tr>
                </table></td>
              </tr>
            </table>
