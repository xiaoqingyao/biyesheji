<style type="text/css">
<!--
.STYLE1 {color: #FFFFFF}
.STYLE4 {color: #FFFFFF; font-weight: bold; }
.STYLE5 {color: #000000}
-->
</style>
<table id="__01" width="1002" border="0" cellpadding="0" cellspacing="0">
           <tr>
		   <td height="50" align="right" background="qtimages/1_01_02.jpg"><table width="100%" border="0">
             <tr>
               <td><object classid=clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA id=RAOCX name=rmplay > 
						              <param name="SRC" value="qtimages/ddd.mp3"> 
						              <param name="CONSOLE" value="Clip1"> 
						              <param name="CONTROLS" value="imagewindow"> 
						              <param name="AUTOSTART" value="true"> 
						              �� 
				                </object></td>
               <td><?php 
					if ($_SESSION['cx']=="" )
					{
				?>
                 <table width="70%" align="right" height="30" border="0" cellpadding="0" cellspacing="0">
                   <form action="userlog_post.php" method="post" name="userlog" id="userlog">
                     <tr>
                       <td  height="30" align="right" ><span class="STYLE4">�û���</span>
                         <input name="username" type="text" id="username" size="10" style=" height:19px; border:solid 1px #000000; color:#666666" />
                         <span class="STYLE4">����</span>
                         <input name="pwd1" type="password" id="pwd1" size="10" style=" height:19px; border:solid 1px #000000; color:#666666" />
                         <!--Ȩ�� 
                            <select name="cx" id="cx" style="width:100px; height:20px; border:solid 1px #000000; color:#666666" >
                              <option value="ע���û�">ע���û�</option>
                            </select> -->
                         <span class="STYLE4">��֤��</span>
                       <input name="yzm" type="text" id="yzm" style=" height:20px; border:solid 1px #000000; color:#666666; width:50px" /></td>
                       <td width="58" align="right"  style=" padding-left:3px; padding-right:23px;"><img alt="ˢ����֤��" onclick="this.src='code.php?time='+new Date().getTime();" src="code.php?time='+new Date().getTime();" style="cursor:pointer;" /></td>
                       <td width="91" align="left"><input type="submit" name="Submit3" value="��½" style=" border:solid 1px #000000; color:#666666; width:60px; height:20px;" onclick="return checklog();" />
                           <input type="button" name="Submit3" value="�һ�����" onclick="javascript:location.href='zmm.php';" style=" border:solid 1px #000000; color:#666666;width:60px; height:20px; display:none" /></td>
                     </tr>
                   </form>
                 </table>
                 <?php 
							}
				  else
				  {
				 ?>
                 <table width="37%" height="30" align="right" border="0" cellpadding="0" cellspacing="0">
                   <tr>
                     <td height="30" align="left" valign="middle"><span class="STYLE1"><strong>�û���</strong>:<?php echo $_SESSION['username']?>��<strong>����Ȩ��:</strong> <?php echo $_SESSION['cx']?></span>
                         <input type="button" name="Submit" value="�˳�" onclick="location.href='logout.php';"  style=" border:solid 1px #000000; color:#666666; width:60px; height:20px;" />
                         <input type="button" name="Submit2" value="���˺�̨" onclick="location.href='main.php';"  style=" border:solid 1px #000000; color:#666666; width:70px; height:20px;" /></td>
                   </tr>
                 </table>
               <?php
				 }
				 ?></td>
             </tr>
           </table></td>
          </tr>
		  <tr>
            <td width="1002" height="48" valign="bottom" background="qtimages/1_01_01.jpg"><table width="78%" height="25" border="0" align="center" cellpadding="0" cellspacing="0" class="red">
              <tr>
                <td align="center" valign="top"><strong><a href="index.php"><font  class="STYLE5">��ҳ</font></a></strong></td>
                <td align="center" valign="top"><strong><a href="dx_detail.php?lb=���˼��"><font  class="STYLE5">���˼��</font></a></strong></td>
                <td align="center" valign="top"><strong><a href="news2.php?lb=�ҵ���־"><font  class="STYLE5">�ҵ���־</font></a></strong></td>
				<td align="center" valign="top"><strong><a href="news.php?lb=�ҵ�����"><font  class="STYLE5">�ҵ�����</font></a></strong></td>
                <td align="center" valign="top"><strong><a href="lyblist.php"><font  class="STYLE5">���԰�</font></a></strong></td>
                <td align="center" valign="top"><strong><a href="news.php?lb=������Ϣ"><font  class="STYLE5">������Ϣ</font></a></strong></td>
				<td align="center" valign="top"><strong><a href="news4.php?lb=ͼƬ����"><font  class="STYLE5">ͼƬ����</font></a></strong></td>
				<td align="center" valign="top"><strong><a href="userreg.php"><font  class="STYLE5">��Աע��</font></a></strong></td>
				<td align="center" valign="top"><strong><a href="login.html"><font  class="STYLE5">��̨</font></a></strong></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td width="1002" height="208" background="qtimages/1_01_02.jpg"><div align="center">
              <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="924" height="149">
              <param name="movie" value="qtimages/15.swf" />
              <param name="quality" value="high" />
              <param name="wmode" value="transparent">
			  
              <param name="SCALE" value="noborder" />
              <embed src="qtimages/15.swf"  wmode="transparent" width="924" height="149" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" scale="noborder"></embed>
            </object>
            </div>
			<div id="Layer1">
            <div align="center"  style="color:#FFFFFF;font-size: 26pt; font-weight: bold; line-height:80px"></div>
            </div></td>
          </tr>
         
        </table>
