<?php
session_start();

?>
<link rel="stylesheet" href="images/StyleSheet.css" type="text/css" />

<style type="text/css">
<!--
.STYLE2 {color: #00FFFF}
.STYLE5 {color: #72AC27;
	font-size: 26pt;
}
-->
</style>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table id="__01" width="100%" height="87" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="2"><table id="__01" width="100%" height="56" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="863" height="56" background="images/11_01_01_01.gif"><table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="13%"><div align="center"><img src="images/logo.gif" width="36" height="40"></div></td>
            <td width="87%"><table width="100%" border="0" align="center">
              <tr>
                <td><div style="font-family:����; color:#0066cc; WIDTH: 100%; FONT-WEIGHT: bold; FONT-SIZE: 28px; margin-top:5pt">
                   
                      ���˲���ϵͳ
                </div></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
        <td background="images/11_01_01_01.gif"><table id="__01" width="100%" height="56" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td background="images/a4_01.gif">&nbsp;</td>
            <td width="57" height="56" background="images/a4_02.gif"><table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td height="36">&nbsp;</td>
              </tr>
              <tr>
                <td><div align="center"><a href="sy.php" target="mainFrame" class="STYLE2">��ʾ����</a></div></td>
              </tr>
            </table></td>
            <td width="60" height="56" background="images/a4_03.gif"><table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td height="36">&nbsp;</td>
              </tr>
              <tr>
                <td><div align="center"><a href="yhzhgl.php" target="mainFrame" class="STYLE2">�û�����</a></div></td>
              </tr>
            </table></td>
            
            <td width="60" height="56" background="images/a4_05.gif"><table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td height="36">&nbsp;</td>
              </tr>
              <tr>
                <td><div align="center"><A class=STYLE2 
      onclick="showModalDialog('about.htm',window,'dialogHeight:250px;dialogWidth:360px;dialogleft:200px;help:no;status:no;scroll:no');" style="cursor:hand">ʹ�ð���</A></div></td>
              </tr>
            </table></td>
           
			<td width="61" height="56" background="images/a4_04.gif"><table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td height="36">&nbsp;</td>
              </tr>
              <tr>
                <td><div align="center"><a href="logout.php" target="_parent" class="STYLE2">�뿪�˳�</a></div></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td width="35%" height="31" background="images/11_01_02.gif">&nbsp;</td>
    <td width="65%" background="images/fr.gif">&nbsp;</td>
  </tr>
</table>

</body>