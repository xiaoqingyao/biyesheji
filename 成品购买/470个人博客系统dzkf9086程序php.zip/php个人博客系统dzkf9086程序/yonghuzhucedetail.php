<?php
session_start();
include_once 'conn.php';
$zh=$_GET["zh"];
?>
<html>
<head>
<title>�����˲���Ƹϵͳ</title>
<LINK href="qtimages/style.css" type=text/css rel=stylesheet>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<style type="text/css">
<!--
.STYLE5 {	color: #FFFFFF;
	font-weight: bold;
}
.STYLE6 {font-size: 12pt}
.STYLE7 {color: #993300; font-weight: bold; }
-->
</style>
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="1023" height="1200" border="0" align="center" cellpadding="0" cellspacing="0" id="__01">
	<tr>
		<td><?php include_once 'qttop.php';?></td>
	</tr>
	<tr>
		<td><table id="__01" width="1023" height="752" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td valign="top" bgcolor="#F6FCFB"><?php include_once 'qtleft.php';?></td>
            <td valign="top"><table id="__01" width="805" height="752" border="0" cellpadding="0" cellspacing="0">
              
              <tr>
                <td valign="top"><table id="__01" width="805" height="209" border="0" cellpadding="0" cellspacing="0">
                  <tr>
                    <td width="805" height="35" background="qtimages/1_02_02_02_01.gif"><table width="100%" height="17" border="0" cellpadding="0" cellspacing="0">
                      <tr>
                        <td width="19%" height="17" align="center" valign="bottom"><font class="STYLE5">��Ա��ϸ</font></td>
                        <td width="81%">&nbsp;</td>
                      </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td><table id="__01" width="805" height="164" border="0" cellpadding="0" cellspacing="0">
                      <tr>
                        <td width="11" background="qtimages/1_02_02_02_02_01.gif">&nbsp;</td>
                        <td width="778" height="706" valign="top"><?php
$sql="select * from yonghuzhuce where zhanghao='".$zh."'";
$query=mysql_query($sql);
$rowscount=mysql_num_rows($query);
if($rowscount>0)
{
$i=0;
?>
                          <form id="form1" name="form1" method="post" action="">
                            <table width="100%" border="1" align="center" cellpadding="3" cellspacing="1" bordercolor="#00FFFF" style="border-collapse:collapse">
                              <tr>
                                <td width="11%">�˺ţ�</td>
                                <td width="58%"><?php echo mysql_result($query,$i,zhanghao);?></td>
                                <td colspan="2" rowspan="6"><img src="<?php echo mysql_result($query,$i,zhaopian);?>" width="186" height="138"></td>
                                </tr>
                              
                              <tr>
                                <td>������</td>
                                <td><?php echo mysql_result($query,$i,xingming);?></td>
                                </tr>
                              <tr>
                                <td>�Ա�</td>
                                <td><?php echo mysql_result($query,$i,xingbie);?> </td>
                                </tr>
                              <tr>
                                <td>������</td>
                                <td><?php echo mysql_result($query,$i,diqu);?></td>
                                </tr>
                              <tr>
                                <td>Email��</td>
                                <td><?php echo mysql_result($query,$i,Email);?></td>
                                </tr>
                              
                              <tr>
                                <td height="27">������</td>
                                <td><a href="<?php echo mysql_result($query,$i,jianli);?>">�������</a></td>
                                </tr>
                              <tr>
                                <td colspan="4" align="center"><input type="button" name="Submit2" value="��ӡ" onClick="javascript:window.print();" /></td>
                                </tr>
                            </table>
                          </form>
                          <?php
	}
?>
                          <p></p>
                          <p align="center">&nbsp;</p></td>
                        <td width="16" background="qtimages/1_02_02_02_02_03.gif">&nbsp;</td>
                      </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td><img src="qtimages/1_02_02_02_03.gif" width="805" height="10" alt=""></td>
                  </tr>
                </table></td>
              </tr>
              
            </table></td>
          </tr>
        </table></td>
	</tr>
	<tr>
		<td><?php include_once 'qtdown.php';?></td>
	</tr>
</table>
</body>
</html>