<?php
session_start();
include_once 'conn.php';
?>
<html>
<head>
<title>���˲���ϵͳ</title>
<LINK href="qtimages/style.css" type=text/css rel=stylesheet>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<style type="text/css">
<!--
.STYLE1 {color: #D92B8A}
body {
	background-color: #0099CC;
}
.STYLE2 {
	color: #FFFFFF;
	font-weight: bold;
}
.STYLE7 {color: #993300; font-weight: bold; }
-->
</style>
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="1002" height="1203" border="0" align="center" cellpadding="0" cellspacing="0" id="__01">
	<tr>
		<td><?php include_once 'qttop.php';?></td>
	</tr>
	<tr>
		<td><table id="__01" width="1002" height="816" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td valign="top" background="qtimages/3.jpg"><?php include_once 'qtleft.php';?></td>
            <td valign="top" background="qtimages/2.jpg"><table id="__01" width="766" height="816" border="0" cellpadding="0" cellspacing="0">
              
              <tr>
                <td valign="top"><table id="__01" width="766" height="254" border="0" cellpadding="0" cellspacing="0">
                  <tr>
                    <td width="766" height="47" background="qtimages/1_02_02_01_01.jpg"><table width="100%" height="17" border="0" cellpadding="0" cellspacing="0">
                      <tr>
                        <td width="13%" height="17" align="right" valign="bottom"><span class="STYLE2"><strong>��Ա��ѯ</strong></span></td>
                        <td width="87%">&nbsp;</td>
                      </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td><table id="__01" width="766" height="197" border="0" cellpadding="0" cellspacing="0">
                        <tr>
                          <td width="11" background="qtimages/1_02_02_01_02_01.jpg">&nbsp;</td>
                          <td width="728" height="760" valign="top" bgcolor="#FFFFFF"><form id="form1" name="form1" method="post" action="">
                            ����:�˺�:
                            <input name="bh" type="text" id="bh" />
                            ����:
  <input name="mc" type="text" id="mc" />
  <input type="submit" name="Submit" value="����" />
                          </form>
                            <table width="100%" border="1" align="center" cellpadding="3" cellspacing="1" bordercolor="#579836" style="border-collapse:collapse">
                              <tr>
                                <td width="31" bgcolor="#9DFDDE">���</td>
                                <td width="63" bgcolor='#9DFDDE'>�˺�</td>
                                <td width="72" bgcolor='#9DFDDE'>����</td>
                                <td width="72" bgcolor='#9DFDDE'>�Ա�</td>
                                <td width="125" bgcolor='#9DFDDE'>����</td>
                                <td width="156" bgcolor='#9DFDDE'>Email</td>
                                <td width="82" bgcolor='#9DFDDE'>��Ƭ</td>
                                <td width="96" align="center" bgcolor="#9DFDDE">ע��ʱ��</td>
                                <td width="96" align="center" bgcolor="#9DFDDE">����</td>
                              </tr>
                              <?php 
    $sql="select * from yonghuzhuce where 1=1";
  if ($_POST["bh"]!="")
{
  	$nreqbh=$_POST["bh"];
  	$sql=$sql." and zhanghao like '%$nreqbh%'";
}
     if ($_POST["mc"]!="")
{
  	$nreqmc=$_POST["mc"];
  	$sql=$sql." and xingming like '%$nreqmc%'";
}
  $sql=$sql." order by id desc";
  
$query=mysql_query($sql);
  $rowscount=mysql_num_rows($query);
  if($rowscount==0)
  {}
  else
  {
  $pagelarge=10;//ÿҳ������
  $pagecurrent=$_GET["pagecurrent"];
  if($rowscount%$pagelarge==0)
  {
		$pagecount=$rowscount/$pagelarge;
  }
  else
  {
   		$pagecount=intval($rowscount/$pagelarge)+1;
  }
  if($pagecurrent=="" || $pagecurrent<=0)
{
	$pagecurrent=1;
}
 
if($pagecurrent>$pagecount)
{
	$pagecurrent=$pagecount;
}
		$ddddd=$pagecurrent*$pagelarge;
	if($pagecurrent==$pagecount)
	{
		if($rowscount%$pagelarge==0)
		{
		$ddddd=$pagecurrent*$pagelarge;
		}
		else
		{
		$ddddd=$pagecurrent*$pagelarge-$pagelarge+$rowscount%$pagelarge;
		}
	}

	for($i=$pagecurrent*$pagelarge-$pagelarge;$i<$ddddd;$i++)
{
  ?>
                              <tr>
                                <td width="31"><?php
	echo $i+1;
?></td>
                                <td><?php echo mysql_result($query,$i,zhanghao);?></td>
                                <td><?php echo mysql_result($query,$i,xingming);?></td>
                                <td><?php echo mysql_result($query,$i,xingbie);?></td>
                                <td><?php echo mysql_result($query,$i,diqu);?></td>
                                <td><?php echo mysql_result($query,$i,Email);?></td>
                                <td align="center"><a href="<?php echo mysql_result($query,$i,zhaopian);?>" target="_blank"><img src="<?php echo mysql_result($query,$i,zhaopian);?>" width="73" height="77" border="0" /></a></td>
                                <td width="96" align="center"><?php
echo mysql_result($query,$i,"addtime");
?></td>
                                <td width="96" align="center"><a href="haoyouxinxiadd.php?id=<?php echo mysql_result($query,$i,id);?>">��Ϊ����</a></td>
                              </tr>
                              <?php
	}
}
?>
                            </table>
                            <p>�������ݹ�
                              <?php
		echo $rowscount;
	?>
                              ��,
  <input type="button" name="Submit2" onClick="javascript:window.print();" value="��ӡ��ҳ" />
                            </p>
                            <p align="center"><a href="yonghuzhucelist.php?pagecurrent=1">��ҳ</a>, <a href="yonghuzhucelist.php?pagecurrent=<?php echo $pagecurrent-1;?>">ǰһҳ</a> ,<a href="yonghuzhucelist.php?pagecurrent=<?php echo $pagecurrent+1;?>">��һҳ</a>, <a href="yonghuzhucelist.php?pagecurrent=<?php echo $pagecount;?>">ĩҳ</a>, ��ǰ��<?php echo $pagecurrent;?>ҳ,��<?php echo $pagecount;?>ҳ </p></td>
                          <td width="27" background="qtimages/1_02_02_01_02_03.jpg">&nbsp;</td>
                        </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td><img src="qtimages/1_02_02_01_03.jpg" width="766" height="10" alt=""></td>
                  </tr>
                </table></td>
              </tr>
              
            </table></td>
          </tr>
        </table></td>
	</tr>
	<tr>
		<td><?php include_once 'qtdown.php';?></td>
	</tr>
</table>
</body>
</html>